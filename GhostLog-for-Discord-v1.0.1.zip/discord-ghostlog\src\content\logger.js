/* GhostLog for Discord — content script.
 *
 * Watches the rendered chat list only. It never reads your token, never touches
 * the gateway socket, and never makes a network request of its own. Everything
 * it learns is what your own client already painted on screen.
 */
(() => {
  'use strict';

  if (window.__ghostlogLoaded) return;
  window.__ghostlogLoaded = true;

  // -------------------------------------------------------------------------
  // constants / tunables
  // -------------------------------------------------------------------------

  const MSG_ID_RE = /^chat-messages-(?:(\d+)-)?(\d+)$/;
  const DISCORD_EPOCH = 1420070400000n;

  const CONFIRM_DELAY_MS = 750;   // wait this long before believing a removal
  const SCROLL_GRACE_MS = 900;    // removals this soon after a user scroll = virtualisation
  const MAX_BATCH_FOR_DELETE = 25; // bigger removals are a re-render, not a purge
  const FLUSH_INTERVAL_MS = 1500;
  const RECENT_SEND_MS = 60000;   // beyond this, a message is history, not a pending send
  const PENDING_TTL_MS = 8000;    // how long a "sending" guess may suppress anything
  const BACKFILL_DELAY_MS = 1200; // settle time before scanning for gaps
  const FORCED_SCAN_INTERVAL_MS = 15000; // floor between speculative rescans
  const SUSPECT_REVIEW_MS = 5000; // settle time before re-examining a scroll removal

  const DEFAULTS = {
    enabled: true, ghostsInline: true, logEdits: true, strictMode: false, stealth: false,
    backfill: true, debug: false, sidebarBadges: true,
    alwaysTimestamps: true, accent: '#ed4245', ghostFade: 0, keywords: [],
    notifyKeywords: false, ignoredGuilds: [], ignoreDMs: false,
    storeMedia: 'deleted', mediaMaxImageMB: 8, mediaMaxAudioMB: 12,
    mediaMaxVideoMB: 25, mediaBudgetMB: 500,
    retentionDays: 30, maxRecords: 50000
  };

  let settings = { ...DEFAULTS };

  // -------------------------------------------------------------------------
  // state
  // -------------------------------------------------------------------------

  const tracked = new Map();      // messageId -> record (currently in the DOM)
  const ghostNodes = new Map();   // messageId -> our injected <li>
  const writeQueue = new Map();   // messageId -> record awaiting flush
  const deletionsHere = new Map();// channelId -> count this session
  const sentContent = new Map();  // messageId -> last content we shipped
  const pendingIds = new Set();   // messages still in Discord's "sending" state
  const deferredGhosts = new Map();// ghosts waiting for their history to render
  const dismissedGhosts = new Set();// ghosts the user closed by hand this session

  let pendingRemovals = [];
  let confirmTimer = null;
  let flushTimer = null;

  let lastUserScrollTs = 0;
  let route = { guildId: null, channelId: null, guildName: null, channelName: null };
  let listEl = null;
  let listObserver = null;
  let editObserver = null;
  let idObserver = null;

  // -------------------------------------------------------------------------
  // small helpers
  // -------------------------------------------------------------------------

  function send(type, payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type, payload }, (res) => {
          void chrome.runtime.lastError; // extension reloaded mid-session; ignore
          resolve(res);
        });
      } catch {
        resolve(null); // context invalidated
      }
    });
  }

  /** Narrates every decision to the page console when debug is on. */
  function trace(...args) {
    if (settings.debug) console.log('%c[GhostLog]', 'color:#ed4245;font-weight:700', ...args);
  }

  function snowflakeToMs(id) {
    try { return Number((BigInt(id) >> 22n) + DISCORD_EPOCH); }
    catch { return Date.now(); }
  }

  function parseMessageId(el) {
    if (!el || el.nodeType !== 1 || !el.id) return null;
    const m = MSG_ID_RE.exec(el.id);
    return m ? { channelId: m[1] || null, messageId: m[2] } : null;
  }

  function isMessageNode(el) {
    return !!parseMessageId(el);
  }

  const q = (root, sel) => { try { return root.querySelector(sel); } catch { return null; } };

  // -------------------------------------------------------------------------
  // route (which server / channel are we looking at)
  // -------------------------------------------------------------------------

  function readRoute() {
    const m = /\/channels\/(@me|\d+)\/(\d+)/.exec(location.pathname);
    const guildId = m ? (m[1] === '@me' ? null : m[1]) : null;
    const channelId = m ? m[2] : null;

    // document.title reads "#general | My Server - Discord" (optionally "(3) " prefixed)
    let channelName = null;
    let guildName = null;
    const title = document.title.replace(/^\(\d+\)\s*/, '').replace(/\s*-\s*Discord$/, '');
    if (title.includes(' | ')) {
      const [left, right] = title.split(' | ');
      channelName = left.replace(/^#/, '').trim();
      guildName = right.trim();
    } else if (title) {
      channelName = title.replace(/^[#@]/, '').trim();
    }

    if (!channelName) {
      const header = q(document, '[class*="title_"] [class*="name"]') || q(document, 'h1[class*="title"]');
      if (header) channelName = header.textContent.trim();
    }
    if (!guildId) guildName = 'Direct Messages';

    return { guildId, channelId, guildName, channelName };
  }

  function refreshRoute() {
    const next = readRoute();
    const changed = next.channelId !== route.channelId;
    route = next;
    if (changed) {
      // a channel switch tears the whole list down; nothing pending is a real delete
      pendingRemovals = [];
      tracked.clear();
      ghostNodes.clear();
      pendingIds.clear();
      deferredGhosts.clear();
      dismissedGhosts.clear();
      suspects.clear();
      scanned = { channelId: null, minTs: Infinity, maxTs: -Infinity };
      updateCounter();
      if (next.channelId) {
        send('badge:ack', { channelId: next.channelId }).then(refreshBadges);
      }
    }
    return changed;
  }

  // -------------------------------------------------------------------------
  // message parsing
  // -------------------------------------------------------------------------

  /** Text of a message, with custom emoji rendered as :name: and <br> as newline. */
  function readContent(node) {
    if (!node) return '';
    let out = '';
    const walk = (n) => {
      for (const child of n.childNodes) {
        if (child.nodeType === 3) { out += child.nodeValue; continue; }
        if (child.nodeType !== 1) continue;
        const tag = child.tagName;
        if (tag === 'BR') { out += '\n'; continue; }
        if (tag === 'IMG') {
          const alt = child.getAttribute('alt');
          if (alt) out += alt;
          continue;
        }
        walk(child);
      }
    };
    walk(node);
    return out.replace(/[\u200b\u200e\u200f\ufeff]/g, '').trim();
  }

  function readAuthor(li, messageId) {
    const nameEl = q(li, `#message-username-${messageId} [class*="username"]`)
      || q(li, `#message-username-${messageId}`)
      || q(li, '[class*="username"]');

    let authorName = nameEl ? nameEl.textContent.trim() : null;

    // author id: data attribute if present, otherwise dig it out of the avatar URL
    let authorId = null;
    const withAttr = q(li, '[data-author-id]');
    if (withAttr) authorId = withAttr.getAttribute('data-author-id');

    let avatar = null;
    const img = q(li, 'img[class*="avatar"]');
    if (img && img.src) {
      avatar = img.src;
      if (!authorId) {
        const am = /\/(?:avatars|users)\/(\d+)\//.exec(img.src);
        if (am) authorId = am[1];
      }
    }

    const bot = !!q(li, '[class*="botTag"]');
    return { authorName, authorId, avatar, bot };
  }

  /**
   * Grouped ("compact") messages carry no header — they inherit the author of
   * the last message above them that did.
   */
  function inheritAuthor(li) {
    let sib = li.previousElementSibling;
    let hops = 0;
    while (sib && hops < 60) {
      const ids = parseMessageId(sib);
      if (ids) {
        const known = tracked.get(ids.messageId);
        if (known && known.authorName) {
          return { authorName: known.authorName, authorId: known.authorId, avatar: known.avatar, bot: known.bot };
        }
        const parsed = readAuthor(sib, ids.messageId);
        if (parsed.authorName) return parsed;
      }
      sib = sib.previousElementSibling;
      hops++;
    }
    return { authorName: null, authorId: null, avatar: null, bot: false };
  }

  const IMAGE_RE = /\.(png|jpe?g|gif|webp|bmp|avif|apng|svg)(\?|$)/i;
  const VIDEO_RE = /\.(mp4|webm|mov|m4v|mkv)(\?|$)/i;
  const AUDIO_RE = /\.(mp3|ogg|oga|wav|flac|m4a|aac|opus)(\?|$)/i;

  function fileNameFromUrl(url) {
    try {
      const path = new URL(url).pathname;
      return decodeURIComponent(path.slice(path.lastIndexOf('/') + 1)) || null;
    } catch {
      return null;
    }
  }

  /** image / video / audio / file, from the extension or the element it came from. */
  function classifyMedia(url, hint) {
    if (hint) return hint;
    if (IMAGE_RE.test(url)) return 'image';
    if (VIDEO_RE.test(url)) return 'video';
    if (AUDIO_RE.test(url)) return 'audio';
    return 'file';
  }

  /**
   * Discord serves the same upload from several hosts and rewrites images
   * through media.discordapp.net with resize parameters. Prefer the original
   * cdn.discordapp.com URL so what gets saved is the full-quality file.
   */
  function preferOriginal(url) {
    try {
      const u = new URL(url);
      if (u.hostname === 'media.discordapp.net') {
        u.hostname = 'cdn.discordapp.com';
        u.searchParams.delete('width');
        u.searchParams.delete('height');
        u.searchParams.delete('format');
        u.searchParams.delete('quality');
        u.searchParams.delete('size');
      }
      return u.toString();
    } catch {
      return url;
    }
  }

  function readAttachments(li, messageId) {
    const box = q(li, `#message-accessories-${messageId}`);
    if (!box) return [];
    const out = [];

    const push = (url, kind, name) => {
      if (!url || !/^https?:/.test(url)) return;
      const full = preferOriginal(url);
      out.push({
        kind: classifyMedia(full, kind),
        url: full,
        name: name || fileNameFromUrl(full)
      });
    };

    for (const img of box.querySelectorAll('img[src]')) {
      if (img.closest('[class*="emoji"]') || img.closest('[class*="reaction"]')) continue;
      push(img.getAttribute('src') || img.src, 'image', img.getAttribute('alt'));
    }
    for (const v of box.querySelectorAll('video[src], video source[src]')) {
      push(v.getAttribute('src'), 'video', null);
      if (v.poster) push(v.poster, 'image', null);
    }
    for (const a of box.querySelectorAll('audio[src], audio source[src]')) {
      push(a.getAttribute('src'), 'audio', null);
    }
    // voice messages and file cards are plain links
    for (const a of box.querySelectorAll('a[href]')) {
      const href = a.getAttribute('href');
      if (!href) continue;
      const named = q(a, '[class*="filename"]');
      push(href, null, named ? named.textContent.trim() : (a.textContent.trim() || null));
    }

    // de-dupe on the signature-free key, so the same upload is not stored twice
    const seen = new Set();
    const unique = [];
    for (const item of out) {
      const key = item.url.split('?')[0];
      if (seen.has(key)) continue;
      seen.add(key);
      unique.push(item);
    }
    return unique.slice(0, 12);
  }

  function readReply(li, messageId) {
    const ref = q(li, `#message-reply-context-${messageId}`) || q(li, '[id^="message-reply-context-"]');
    if (!ref) return null;
    const who = q(ref, '[class*="username"]');
    const what = q(ref, '[class*="repliedTextContent"]') || q(ref, '[id^="message-content-"]');
    return {
      authorName: who ? who.textContent.trim() : null,
      content: what ? readContent(what).slice(0, 200) : null
    };
  }

  function buildRecord(li) {
    const ids = parseMessageId(li);
    if (!ids) return null;
    const { messageId } = ids;

    let author = readAuthor(li, messageId);
    if (!author.authorName) author = inheritAuthor(li);

    const contentEl = q(li, `#message-content-${messageId}`);
    const content = readContent(contentEl);
    const attachments = readAttachments(li, messageId);
    if (!content && attachments.length === 0 && !author.authorName) return null;

    const timeEl = q(li, 'time[datetime]');
    const domTs = timeEl ? Date.parse(timeEl.getAttribute('datetime')) : NaN;

    return {
      id: messageId,
      ts: Number.isFinite(domTs) ? domTs : snowflakeToMs(messageId),
      guildId: route.guildId,
      guildName: route.guildName,
      channelId: ids.channelId || route.channelId,
      channelName: route.channelName,
      authorId: author.authorId,
      authorName: author.authorName || 'Unknown',
      avatar: author.avatar,
      bot: author.bot,
      content,
      attachments,
      reply: readReply(li, messageId),
      edits: [],
      firstSeen: Date.now()
    };
  }

  // -------------------------------------------------------------------------
  // write queue
  // -------------------------------------------------------------------------

  function enqueue(record) {
    writeQueue.set(record.id, record);
    if (!flushTimer) flushTimer = setTimeout(flush, FLUSH_INTERVAL_MS);
  }

  function flush() {
    flushTimer = null;
    if (writeQueue.size === 0) return;
    const records = [...writeQueue.values()];
    writeQueue.clear();
    send('log:batch', { records });
  }

  // -------------------------------------------------------------------------
  // keyword watch
  // -------------------------------------------------------------------------

  /**
   * Messages render before the settings round-trip resolves, and the keyword
   * list can change at any time — so re-mark everything on screen rather than
   * only testing messages at the moment they arrive.
   */
  function rescanKeywords() {
    for (const li of document.querySelectorAll('[data-ghostlog-hit]')) {
      li.removeAttribute('data-ghostlog-hit');
    }
    if (!settings.keywords.length || !listEl) return;
    for (const li of listEl.children) {
      const ids = parseMessageId(li);
      if (!ids) continue;
      const record = tracked.get(ids.messageId);
      if (record) checkKeywords(li, record, true);
    }
  }

  function checkKeywords(li, record, quiet) {
    if (!settings.keywords.length || !record.content) return;
    const hay = record.content.toLowerCase();
    const hit = settings.keywords.find((k) => k && hay.includes(k.toLowerCase()));
    if (!hit) return;
    if (!settings.stealth) li.setAttribute('data-ghostlog-hit', '1');
    // only notify for something that just arrived — opening a channel renders
    // pages of history, and every keyword hit in it is old news
    const isNew = Date.now() - record.ts < RECENT_SEND_MS;
    if (settings.notifyKeywords && !quiet && isNew) {
      send('notify:keyword', {
        authorName: record.authorName,
        channelName: record.channelName || 'unknown',
        content: record.content
      });
    }
  }

  // -------------------------------------------------------------------------
  // ingest / removal
  // -------------------------------------------------------------------------

  /**
   * A message you just sent is rendered optimistically under a temporary nonce
   * id and only gets its real id once the server acks. Discord marks that state
   * on the message element, so the node can be recognised before it is swapped.
   */
  function isPendingNode(li, record) {
    // Class names are hashed and change between Discord builds, so this guess is
    // only ever allowed to affect a message that is seconds old. It must never
    // get a vote about ordinary chat history.
    if (record && Date.now() - record.ts > RECENT_SEND_MS) return false;
    if (q(li, '[class*="isSending"], [class*="isFailed"], [class*="sendFailed"]')) return true;
    return /isSending|isFailed|sendFailed/.test(li.className || '');
  }

  /**
   * Forget a temporary record locally. Only removes it from the archive when the
   * caller is certain it was a placeholder — deleting real history is far worse
   * than leaving a stray row behind.
   */
  function discardStale(id, fromArchive) {
    writeQueue.delete(id);
    sentContent.delete(id);
    pendingIds.delete(id);
    if (fromArchive) send('log:discard', { id });
  }

  /**
   * Was this removal actually a swap? When the server confirms a send, the
   * temporary node is replaced by an equivalent one carrying the real id, in
   * the same render. Same author, same text, appearing right as the old one
   * left, means nothing was deleted.
   */
  function wasReplaced(item) {
    // a send confirmation only ever concerns a message that is seconds old
    if (Date.now() - item.record.ts > RECENT_SEND_MS) return null;
    const lo = item.at - 800;
    const hi = item.at + 1000;
    for (const [id, rec] of tracked) {
      if (id === item.record.id) continue;
      if (!rec.firstSeen || rec.firstSeen < lo || rec.firstSeen > hi) continue;
      if (rec.authorName !== item.record.authorName) continue;
      if (rec.content !== item.record.content) continue;
      return id;
    }
    return null;
  }

  /**
   * Discord sometimes confirms a send by rewriting the id on the existing node
   * rather than replacing it. Re-key the record so the message is archived
   * under its real id instead of the temporary one.
   */
  function handleIdSwap(node, oldValue) {
    if (!oldValue) return;
    const before = MSG_ID_RE.exec(oldValue);
    const after = parseMessageId(node);
    if (!before || !after) return;
    const oldId = before[2];
    if (oldId === after.messageId) return;

    const previous = tracked.get(oldId);
    pendingRemovals = pendingRemovals.filter((pending) => pending.record.id !== oldId);
    tracked.delete(oldId);

    // Erase the old archive row only when this is genuinely a send being
    // confirmed: seconds old, and the same text. Discord also recycles list
    // nodes while scrolling, and that must never delete real history.
    const fresh = buildRecord(node);
    const confirmedSend = !!previous
      && Date.now() - previous.ts < RECENT_SEND_MS
      && (pendingIds.has(oldId) || (!!fresh && fresh.content === previous.content));

    trace(confirmedSend ? 'send confirmed, re-keyed' : 'list node recycled, archive kept', oldId, '->', after.messageId);
    discardStale(oldId, confirmedSend);
    ingest(node);
  }

  function ingest(li) {
    if (li.hasAttribute('data-ghostlog-ghost')) return;
    const ids = parseMessageId(li);
    if (!ids) return;
    if (tracked.has(ids.messageId)) return;

    const record = buildRecord(li);
    if (!record) return;

    tracked.set(record.id, record);

    // A brand-new message still in Discord's "sending" state carries a throwaway
    // id. Note that so a swap is not read as a deletion — but archive it either
    // way. A wrong guess here must never cost a message.
    if (isPendingNode(li, record)) {
      pendingIds.add(record.id);
      setTimeout(() => pendingIds.delete(record.id), PENDING_TTL_MS);
    }

    // React re-mounts the same message constantly while you scroll; only spend a
    // write when the text is genuinely new or has changed since we last sent it.
    const shipped = sentContent.get(record.id);
    if (shipped === undefined || shipped !== record.content) {
      if (sentContent.size > 8000) sentContent.clear();
      sentContent.set(record.id, record.content);
      enqueue(record);
    }

    checkKeywords(li, record);
  }

  function onRemoved(li, mutation) {
    const ids = parseMessageId(li);
    if (!ids) return;
    if (li.hasAttribute('data-ghostlog-ghost')) { ghostNodes.delete(ids.messageId); return; }

    const record = tracked.get(ids.messageId);
    tracked.delete(ids.messageId);
    if (!record || !settings.enabled) return;

    // the temporary node of a message you just sent, being swapped for the real
    // one — never a deletion
    if (pendingIds.has(ids.messageId)) {
      trace('not a deletion: it was still sending |', record.authorName);
      discardStale(ids.messageId, true);
      return;
    }

    const prev = mutation.previousSibling;
    const next = mutation.nextSibling;

    pendingRemovals.push({
      record,
      node: li,                                  // detached, but the subtree is intact
      prevId: isMessageNode(prev) ? parseMessageId(prev).messageId : null,
      nextId: isMessageNode(next) ? parseMessageId(next).messageId : null,
      prevNode: prev,
      nextNode: next,
      channelId: route.channelId,
      list: listEl,
      scrolledRecently: Date.now() - lastUserScrollTs < SCROLL_GRACE_MS,
      at: Date.now()
    });

    if (confirmTimer) clearTimeout(confirmTimer);
    confirmTimer = setTimeout(confirmRemovals, CONFIRM_DELAY_MS);
  }

  /**
   * A node leaving the DOM is not proof of a deletion — Discord virtualises the
   * list and React re-renders constantly. Everything here is about telling those
   * apart from an actual delete.
   */
  function confirmRemovals() {
    confirmTimer = null;
    const batch = pendingRemovals;
    pendingRemovals = [];
    if (!batch.length) return;

    // a large sweep is the list being rebuilt, not 30 people deleting at once
    const tooMany = batch.length > MAX_BATCH_FOR_DELETE;

    for (const item of batch) {
      const why = rejectionReason(item, tooMany);
      if (why) {
        trace('not a deletion:', why, '|', item.record.authorName,
          '-', (item.record.content || '').slice(0, 40));
        if (why === SEND_CONFIRMED) discardStale(item.record.id, true);
        // A removal blamed on scrolling may really have been a deletion. Look
        // again shortly — but at this one message, not by rescanning the whole
        // channel, which is what made scrolling crawl.
        else if (why === VIRTUALISED) suspectVirtualised(item);
        continue;
      }
      commitDeletion(item);
    }
  }

  // Removals we blamed on scrolling, held for a second look.
  const suspects = new Map();
  let suspectTimer = null;

  function suspectVirtualised(item) {
    if (suspects.size > 200) return; // a pathological burst is not worth chasing
    suspects.set(item.record.id, item.record);
    if (!suspectTimer) suspectTimer = setTimeout(reviewSuspects, SUSPECT_REVIEW_MS);
  }

  /**
   * Virtualisation drops messages from the *edges* of the rendered list. So a
   * message that is still missing once scrolling has stopped, and whose time
   * sits strictly inside what is now on screen, was not virtualised away — it
   * was deleted. This costs one pass over the visible list, no database work.
   */
  function reviewSuspects() {
    suspectTimer = null;
    const list = [...suspects.values()];
    suspects.clear();
    if (!list.length || !listEl || !listEl.isConnected) return;

    let minTs = Infinity;
    let maxTs = -Infinity;
    for (const li of listEl.children) {
      const ids = parseMessageId(li);
      if (!ids) continue;
      const t = renderedTs(ids.messageId, li);
      if (t < minTs) minTs = t;
      if (t > maxTs) maxTs = t;
    }
    if (!Number.isFinite(minTs) || !Number.isFinite(maxTs)) return;

    for (const rec of list) {
      if (rec.channelId !== route.channelId) continue;
      if (ghostNodes.has(rec.id) || dismissedGhosts.has(rec.id)) continue;
      if (document.getElementById(`chat-messages-${rec.channelId}-${rec.id}`)
        || document.getElementById(`chat-messages-${rec.id}`)) continue; // it came back
      // strictly inside: at the edges it really could be virtualisation
      if (rec.ts <= minTs || rec.ts >= maxTs) continue;

      trace('deleted after all — the scroll excuse did not hold:', rec.authorName);
      commitDeletion({ record: rec, node: null, list: listEl, channelId: rec.channelId });
    }
  }

  const SEND_CONFIRMED = 'the send was confirmed under a new id';
  const VIRTUALISED = 'you had just scrolled (virtualisation)';

  /**
   * Why this removal is not a deletion, or null when it genuinely is one.
   * Kept as one function so debug mode can name the exact rule that fired.
   */
  function rejectionReason(item, tooMany) {
    if (tooMany) return 'part of a large re-render sweep';
    if (item.channelId !== route.channelId) return 'the channel changed';
    if (item.list && !item.list.isConnected) return 'the message list was torn down';
    if (item.scrolledRecently) return VIRTUALISED;
    if (document.getElementById(`chat-messages-${item.channelId}-${item.record.id}`)
      || document.getElementById(`chat-messages-${item.record.id}`)) {
      return 'the message came straight back (re-render)';
    }
    if (settings.strictMode) {
      const prevAlive = item.prevNode && item.prevNode.isConnected;
      const nextAlive = item.nextNode && item.nextNode.isConnected;
      if (!prevAlive || !nextAlive) return 'strict mode: a neighbour did not survive';
    }
    if (wasReplaced(item)) return SEND_CONFIRMED;
    return null;
  }

  function commitDeletion(item) {
    const deletedAt = Date.now();
    item.record.deletedAt = deletedAt;

    // Ship the whole record with the deletion. The archive write is batched on a
    // timer, so a message deleted seconds after it arrived may not be stored yet
    // — sending it here means a deletion can always be recorded.
    const record = { ...item.record };
    delete record.deletedAt;
    trace('DELETED', item.record.authorName, '-', item.record.content.slice(0, 60));
    send('log:deleted', { id: item.record.id, deletedAt, record });

    const chan = item.channelId || 'unknown';
    deletionsHere.set(chan, (deletionsHere.get(chan) || 0) + 1);
    updateCounter();

    if (settings.ghostsInline && !settings.stealth) renderGhost(item, deletedAt);
  }

  // -------------------------------------------------------------------------
  // ghost rendering
  // -------------------------------------------------------------------------

  function fmtTime(ms) {
    const d = new Date(ms);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function fmtDate(ms) {
    const d = new Date(ms);
    const today = new Date();
    const sameDay = d.toDateString() === today.toDateString();
    return sameDay ? `Today at ${fmtTime(ms)}` : d.toLocaleString([], {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  }

  /** Clone the dead message, strip anything React or the DOM would trip over. */
  function sanitizeClone(node) {
    const clone = node.cloneNode(true);
    clone.removeAttribute('id');
    for (const el of clone.querySelectorAll('[id]')) {
      el.setAttribute('data-ghostlog-was-id', el.id);
      el.removeAttribute('id');
    }
    // hover toolbars and reaction pickers are dead weight on a ghost
    for (const el of clone.querySelectorAll('[class*="buttonContainer"], [class*="buttons_"], [class*="toolbar"]')) {
      el.remove();
    }
    for (const el of clone.querySelectorAll('[tabindex]')) el.setAttribute('tabindex', '-1');
    for (const el of clone.querySelectorAll('a[href]')) el.setAttribute('rel', 'noreferrer noopener');
    return clone;
  }

  function makeButton(label, title, act) {
    const b = document.createElement('button');
    b.className = 'ghostlog-btn';
    b.textContent = label;
    b.title = title;
    b.setAttribute('data-act', act);
    b.type = 'button';
    return b;
  }

  /**
   * Put a ghost where the message belongs in time, never at the end of the
   * list. Returns false when the right spot is above everything currently
   * rendered — the caller should hold the ghost until that history loads,
   * because appending it would strand it under unrelated messages.
   */
  function placeGhost(li, rec, list) {
    const items = [];
    for (const child of list.children) {
      let ts = null;
      if (child.dataset && child.dataset.ghostlogTs) ts = Number(child.dataset.ghostlogTs);
      else {
        const ids = parseMessageId(child);
        if (ids) ts = renderedTs(ids.messageId, child);
      }
      if (ts != null && Number.isFinite(ts)) items.push({ node: child, ts });
    }
    if (!items.length) return false;

    // older than anything loaded: its true neighbours are not on the page yet
    if (rec.ts < items[0].ts) return false;

    const after = items.find((it) => it.ts > rec.ts);
    try {
      if (after) list.insertBefore(li, after.node);
      else list.appendChild(li); // genuinely the newest thing here
    } catch {
      return false; // React moved the anchor out from under us
    }
    return true;
  }

  /**
   * A ghost we drew earlier, but only if it is still on the page. When Discord
   * rebuilds the message list our nodes are detached while the map still points
   * at them — treating those as present is what made every ghost vanish on a
   * refresh and never come back.
   */
  function liveGhost(id) {
    const node = ghostNodes.get(id);
    if (node && node.isConnected) return node;
    if (node) ghostNodes.delete(id);
    return null;
  }

  /** Retry ghosts that were waiting for their part of the channel to render. */
  function retryDeferredGhosts() {
    if (!deferredGhosts.size || !listEl || !listEl.isConnected) return;
    for (const [id, held] of [...deferredGhosts]) {
      if (liveGhost(id)) { deferredGhosts.delete(id); continue; }
      if (document.getElementById(`chat-messages-${route.channelId}-${id}`)) {
        deferredGhosts.delete(id); // it came back; not deleted after all
        continue;
      }
      deferredGhosts.delete(id);
      renderGhost(
        { record: held.record, node: null, list: listEl, channelId: route.channelId },
        held.deletedAt,
        { inferred: held.inferred, redeferred: true }
      );
    }
  }

  function renderGhost(item, deletedAt, opts) {
    const inferred = !!(opts && opts.inferred);
    const list = item.list && item.list.isConnected ? item.list : findList();
    if (!list) return;

    const rec = item.record;
    const li = document.createElement('li');
    li.className = inferred ? 'ghostlog-ghost ghostlog-ghost--away' : 'ghostlog-ghost';
    li.setAttribute('data-ghostlog-ghost', '1');
    li.setAttribute('data-ghostlog-msg', rec.id);

    const bar = document.createElement('div');
    bar.className = 'ghostlog-ghost__bar';

    const icon = document.createElement('span');
    icon.className = 'ghostlog-ghost__icon';
    icon.textContent = 'deleted';

    const who = document.createElement('span');
    who.className = 'ghostlog-ghost__author';
    who.textContent = rec.authorName || 'Unknown';
    if (rec.authorId) who.title = `User ID ${rec.authorId}`;

    const meta = document.createElement('span');
    meta.className = 'ghostlog-ghost__meta';
    meta.textContent = inferred
      ? `sent ${fmtDate(rec.ts)} · deleted while you were away`
      : `sent ${fmtDate(rec.ts)} · removed ${fmtTime(deletedAt)}`;

    const actions = document.createElement('span');
    actions.className = 'ghostlog-ghost__actions';
    actions.append(
      makeButton('copy', 'Copy the message text', 'copy'),
      makeButton('id', 'Copy the message ID', 'id'),
      makeButton('log', 'Open this channel in the archive', 'log'),
      makeButton('×', 'Hide this ghost', 'hide')
    );

    bar.append(icon, who, meta, actions);

    const body = document.createElement('div');
    body.className = 'ghostlog-ghost__body';
    // a backfilled ghost has no original node to clone — rebuild it from the archive
    if (item.node) {
      try { body.appendChild(sanitizeClone(item.node)); }
      catch { body.textContent = rec.content || '(no text content)'; }
    } else {
      const text = document.createElement('div');
      text.className = 'ghostlog-ghost__text';
      text.textContent = rec.content || '(no text content)';
      body.appendChild(text);
    }

    li.append(bar, body);

    // saved attachments render underneath, the way Discord shows them
    if (rec.attachments && rec.attachments.length) {
      const media = document.createElement('div');
      media.className = 'ghostlog-ghost__media';
      li.appendChild(media);
      attachMedia(media, rec);
    }

    li.addEventListener('click', (ev) => {
      const btn = ev.target.closest('button[data-act]');
      if (!btn) return;
      ev.preventDefault();
      ev.stopPropagation();
      const act = btn.getAttribute('data-act');
      if (act === 'copy') { navigator.clipboard.writeText(rec.content || ''); flashButton(btn); }
      if (act === 'id') { navigator.clipboard.writeText(rec.id); flashButton(btn); }
      if (act === 'log') send('open:viewer', { hash: `channel=${rec.channelId}` });
      if (act === 'hide') { dismissedGhosts.add(rec.id); ghostNodes.delete(rec.id); li.remove(); }
    });

    li.dataset.ghostlogTs = String(rec.ts);

    if (!placeGhost(li, rec, list)) {
      // Its place is in history that has not rendered yet. Hold it rather than
      // dropping it at the bottom of the channel, and try again when more of
      // the list loads.
      deferredGhosts.set(rec.id, { record: rec, deletedAt, inferred });
      trace('ghost held until its part of the channel loads:', rec.id);
      return;
    }

    ghostNodes.set(rec.id, li);

    if (settings.ghostFade > 0) {
      setTimeout(() => { li.classList.add('ghostlog-ghost--fading'); }, settings.ghostFade * 1000);
      setTimeout(() => { li.remove(); ghostNodes.delete(rec.id); }, settings.ghostFade * 1000 + 600);
    }
  }

  const AUTOLOAD_IMAGE_CAP = 3 * 1048576; // larger media waits for a click

  function humanSize(n) {
    if (!n) return '';
    const units = ['B', 'KB', 'MB'];
    let i = 0;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return `${n < 10 ? n.toFixed(1) : Math.round(n)} ${units[i]}`;
  }

  /** A player/preview for one saved attachment, matching how Discord shows it. */
  function mediaElement(item) {
    if (item.kind === 'image') {
      const img = document.createElement('img');
      img.className = 'ghostlog-media__image';
      img.src = item.dataUrl;
      img.alt = item.name || 'saved image';
      img.loading = 'lazy';
      return img;
    }
    if (item.kind === 'video') {
      const video = document.createElement('video');
      video.className = 'ghostlog-media__video';
      video.src = item.dataUrl;
      video.controls = true;
      video.preload = 'metadata';
      return video;
    }
    if (item.kind === 'audio') {
      const wrap = document.createElement('div');
      wrap.className = 'ghostlog-media__audio';
      const label = document.createElement('div');
      label.className = 'ghostlog-media__name';
      label.textContent = item.name || 'audio';
      const audio = document.createElement('audio');
      audio.src = item.dataUrl;
      audio.controls = true;
      audio.preload = 'metadata';
      wrap.append(label, audio);
      return wrap;
    }
    return null;
  }

  function mediaChip(text) {
    const chip = document.createElement('div');
    chip.className = 'ghostlog-media__chip';
    chip.textContent = text;
    return chip;
  }

  /**
   * Ask the archive for whatever bytes it kept for this message and render
   * them. Falls back to naming the file when nothing was saved — a link to
   * Discord's CDN is no use once the signature has expired.
   */
  /**
   * Nothing is loaded until the ghost is actually on screen. Restoring a
   * channel can draw many ghosts at once, and decoding every attachment for all
   * of them up front is what made deletions feel slow.
   */
  const pendingMedia = new WeakMap();

  function startMedia(container) {
    const rec = pendingMedia.get(container);
    if (!rec) return; // already loaded
    pendingMedia.delete(container);
    if (mediaObserver) mediaObserver.unobserve(container);
    fillMedia(container, rec);
  }

  const mediaObserver = 'IntersectionObserver' in window
    ? new IntersectionObserver((entries) => {
      for (const entry of entries) if (entry.isIntersecting) startMedia(entry.target);
    }, { rootMargin: '300px' })
    : null;

  function nearViewport(el) {
    const r = el.getBoundingClientRect();
    if (!r.width && !r.height) return false;
    const h = window.innerHeight || document.documentElement.clientHeight || 0;
    return r.bottom > -300 && r.top < h + 300;
  }

  function attachMedia(container, rec) {
    pendingMedia.set(container, rec);
    if (mediaObserver) mediaObserver.observe(container);

    // A document that is not being rendered never delivers intersection
    // callbacks, so check the rectangle directly once layout has settled.
    // Without this the media on a ghost could simply never appear.
    setTimeout(() => {
      if (!mediaObserver || nearViewport(container)) startMedia(container);
    }, 0);
  }

  /** Load a single attachment's bytes and swap it in for its placeholder. */
  async function loadInto(slot, item) {
    slot.textContent = 'loading…';
    const res = await send('media:one', { id: item.id });
    const full = res && res.ok && res.result;
    if (!full || full.missing || !full.dataUrl) {
      slot.textContent = `${item.name || item.kind} — could not be loaded`;
      return;
    }
    const el = mediaElement(full);
    if (!el) { slot.textContent = `${item.name || item.kind} — cannot be shown here`; return; }
    // No autoplay: the audio case returns a wrapper rather than the media
    // element, so calling play() on it threw, and starting sound unprompted in
    // a chat window is unwelcome anyway. The player has controls.
    slot.replaceWith(el);
  }

  async function fillMedia(container, rec) {
    const res = await send('media:for', { messageId: rec.id });
    const saved = (res && res.ok && res.result && res.result.media) || [];
    const byKey = new Map(saved.map((m) => [m.id, m]));
    container.textContent = '';

    for (const att of rec.attachments) {
      const item = byKey.get(att.url.split('?')[0]);

      if (!item) {
        const label = att.name || att.kind;
        container.appendChild(mediaChip(
          att.kind === 'file' ? `📎 ${label}` : `${label} — not saved (link expired or over the size cap)`));
        continue;
      }

      // Images small enough to be cheap appear straight away; anything heavy
      // waits for a click, the way Discord defers large media itself.
      if (item.kind === 'image' && item.size <= AUTOLOAD_IMAGE_CAP) {
        const slot = mediaChip(`${item.name || 'image'} · loading…`);
        container.appendChild(slot);
        loadInto(slot, item);
        continue;
      }

      const verb = item.kind === 'image' ? 'Show' : 'Play';
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'ghostlog-media__load';
      btn.textContent = `${verb} saved ${item.kind} · ${item.name || ''} ${humanSize(item.size)}`.replace(/\s+/g, ' ');
      btn.addEventListener('click', (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        loadInto(btn, item);
      });
      container.appendChild(btn);
    }
  }

  function flashButton(btn) {
    const original = btn.textContent;
    btn.textContent = 'ok';
    setTimeout(() => { btn.textContent = original; }, 900);
  }

  // -------------------------------------------------------------------------
  // edit tracking
  // -------------------------------------------------------------------------

  const editDebounce = new Map();

  function onContentMutated(contentEl) {
    const m = /^message-content-(\d+)$/.exec(contentEl.id || '');
    if (!m) return;
    const id = m[1];
    const record = tracked.get(id);
    if (!record) return;

    clearTimeout(editDebounce.get(id));
    editDebounce.set(id, setTimeout(() => {
      editDebounce.delete(id);
      const live = document.getElementById(`message-content-${id}`);
      if (!live) return;
      const next = readContent(live);
      if (!next || next === record.content) return;

      const previous = record.content;
      record.content = next;
      sentContent.set(id, next);
      send('log:edited', { id, previousContent: previous, at: Date.now() });
      enqueue({ ...record });

      if (settings.stealth) return;
      const li = live.closest('li');
      const n = Number(live.getAttribute('data-ghostlog-edits') || 0) + 1;
      // the badge is a ::after on the content node, so the count lives there
      live.setAttribute('data-ghostlog-edits', String(n));
      if (li) {
        li.setAttribute('data-ghostlog-edits', String(n));
        const prior = li.getAttribute('title');
        const line = `${fmtTime(Date.now())} — was: ${previous}`;
        li.setAttribute('title', prior ? `${prior}\n${line}` : `GhostLog edit history\n${line}`);
      }
    }, 350));
  }

  // -------------------------------------------------------------------------
  // floating counter
  // -------------------------------------------------------------------------

  let counterEl = null;

  function updateCounter() {
    const n = deletionsHere.get(route.channelId) || 0;
    if (!settings.enabled || settings.stealth || n === 0) {
      if (counterEl) { counterEl.remove(); counterEl = null; }
      clearBadges();
      return;
    }
    if (!counterEl) {
      counterEl = document.createElement('div');
      counterEl.className = 'ghostlog-counter';
      counterEl.setAttribute('data-ghostlog-ghost', '1');
      counterEl.title = 'Open the GhostLog archive for this channel';
      counterEl.addEventListener('click', () => {
        send('open:viewer', { hash: `channel=${route.channelId}` });
      });
      document.body.appendChild(counterEl);
    }
    counterEl.textContent = `${n} deleted here`;
  }

  // -------------------------------------------------------------------------
  // observers
  // -------------------------------------------------------------------------

  // -------------------------------------------------------------------------
  // backfill: deletions that happened while you were not looking
  // -------------------------------------------------------------------------

  let backfillTimer = null;
  let lastForcedScan = 0;
  let scanned = { channelId: null, minTs: Infinity, maxTs: -Infinity };

  /**
   * `force` clears the memory of what has already been scanned. Needed whenever
   * a gap could have opened *inside* a window we already looked at — entering a
   * channel, or a removal we declined to call a deletion.
   */
  /**
   * The timestamp we archived for a rendered message. Comparing the window
   * against the archive must use the same clock the archive was written with,
   * not a second one derived from the snowflake.
   */
  function renderedTs(messageId, el) {
    const rec = tracked.get(messageId);
    if (rec) return rec.ts;
    // Not tracked (the list was rebuilt, say). Read the same attribute the
    // archive was written from rather than decoding the snowflake, so ordering
    // and the scan window can never drift onto a different clock.
    const timeEl = el ? q(el, 'time[datetime]') : null;
    const parsed = timeEl ? Date.parse(timeEl.getAttribute('datetime')) : NaN;
    return Number.isFinite(parsed) ? parsed : snowflakeToMs(messageId);
  }

  function scheduleBackfill(opts) {
    if (!settings.enabled || !settings.backfill) return;

    if (opts && opts.force) {
      // Entering a channel must always rescan. A speculative rescan after a
      // scroll must not: scrolling produces a rejection per removed message,
      // and honouring each one meant scanning the channel continuously.
      const now = Date.now();
      if (!opts.immediate && now - lastForcedScan < FORCED_SCAN_INTERVAL_MS) return;
      lastForcedScan = now;
      scanned = { channelId: null, minTs: Infinity, maxTs: -Infinity };
    }

    clearTimeout(backfillTimer);
    backfillTimer = setTimeout(runBackfill, BACKFILL_DELAY_MS);
  }

  /**
   * Compare what is on screen against what the archive holds for the same span
   * of time. Anything archived that sits between two rendered messages but is
   * no longer there was deleted while you were away. Re-runs as you scroll up
   * and more history renders.
   */
  async function runBackfill() {
    if (!settings.enabled || !settings.backfill) return;
    if (!listEl || !listEl.isConnected || !route.channelId) return;

    const presentIds = [];
    const times = [];
    for (const li of listEl.children) {
      const ids = parseMessageId(li);
      if (!ids) continue;
      presentIds.push(ids.messageId);
      times.push(renderedTs(ids.messageId, li));
    }
    if (presentIds.length < 2) return; // too little on screen to bound a gap

    const minTs = Math.min(...times);
    const maxTs = Math.max(...times);

    // only worth re-scanning when the rendered window has actually grown
    const sameChannel = scanned.channelId === route.channelId;
    if (sameChannel && minTs >= scanned.minTs && maxTs <= scanned.maxTs) return;
    scanned = {
      channelId: route.channelId,
      minTs: sameChannel ? Math.min(minTs, scanned.minTs) : minTs,
      maxTs: sameChannel ? Math.max(maxTs, scanned.maxTs) : maxTs
    };

    const res = await send('backfill:scan', {
      channelId: route.channelId, guildId: route.guildId, minTs, maxTs, presentIds
    });
    if (!res || !res.ok || !res.result) return;

    const missing = res.result.rows || [];
    const known = res.result.known || [];
    trace('backfill scanned', presentIds.length, 'rendered messages,',
      missing.length, 'new gap(s),', known.length, 'already on record');

    for (const rec of missing) showAwayGhost(rec);
    // deletions we already recorded: redraw them so a page refresh does not
    // wipe every ghost off the channel
    for (const rec of known) restoreGhost(rec);
    retryDeferredGhosts();
  }

  /** Redraw a deletion that is already in the archive. Records nothing new. */
  function restoreGhost(rec) {
    if (liveGhost(rec.id) || deferredGhosts.has(rec.id) || dismissedGhosts.has(rec.id)) return;
    if (!settings.ghostsInline || settings.stealth) return;
    if (document.getElementById(`chat-messages-${route.channelId}-${rec.id}`)) return;

    renderGhost(
      { record: rec, node: null, list: listEl, channelId: route.channelId },
      rec.deletedAt || Date.now(),
      { inferred: !!rec.inferredDelete }
    );
  }

  /** Record and display a message that vanished while you were elsewhere. */
  function showAwayGhost(rec) {
    if (liveGhost(rec.id) || dismissedGhosts.has(rec.id)) return;
    // Ask the DOM, not the tracked map: the map can hold stale entries for
    // messages that left the page when the list was rebuilt.
    if (document.getElementById(`chat-messages-${route.channelId}-${rec.id}`)
      || document.getElementById(`chat-messages-${rec.id}`)) return;

    const deletedAt = Date.now();
    send('log:deleted', { id: rec.id, deletedAt, record: rec, inferred: true });
    trace('DELETED while away:', rec.authorName, '-', (rec.content || '').slice(0, 60));

    deletionsHere.set(route.channelId, (deletionsHere.get(route.channelId) || 0) + 1);
    updateCounter();

    if (!settings.ghostsInline || settings.stealth) return;

    renderGhost(
      { record: rec, node: null, list: listEl, channelId: route.channelId },
      deletedAt,
      { inferred: true }
    );
  }

  // -------------------------------------------------------------------------
  // sidebar badges: how many messages vanished while you were away
  // -------------------------------------------------------------------------

  let badgeTimer = null;

  /**
   * Every sidebar entry we can attribute to a guild or a channel. Anchors are
   * the durable hook — Discord's class names are hashed, but a server, channel
   * or DM in the sidebar is always a link to /channels/<guild>/<channel>.
   */
  function sidebarTargets() {
    const out = [];

    for (const el of document.querySelectorAll('[data-list-item-id^="guildsnav___"]')) {
      const raw = el.getAttribute('data-list-item-id') || '';
      const m = /guildsnav___(\d+)/.exec(raw);
      if (m) { out.push({ el, kind: 'guild', id: m[1] }); continue; }
      // DMs and group chats live under the home button, whose id is not a
      // guild snowflake — without this they could never be badged
      if (/guildsnav___(home|@me|favou?rites)/.test(raw)) {
        out.push({ el, kind: 'guild', id: '@me' });
      }
    }

    for (const a of document.querySelectorAll('a[href^="/channels/"]')) {
      const m = /^\/channels\/(@me|\d+)\/(\d+)/.exec(a.getAttribute('href') || '');
      if (!m) continue;
      const host = a.closest('li') || a.parentElement;
      if (!host) continue;
      // a guild link in the server rail badges the guild; everything else is a
      // channel or DM row
      if (host.closest('[data-list-item-id^="guildsnav___"]')) continue;
      out.push({ el: host, kind: 'channel', id: m[2] });
    }

    return out;
  }

  function paintBadge(el, count) {
    let badge = el.querySelector(':scope > .ghostlog-badge');
    if (!count) { if (badge) badge.remove(); return; }

    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'ghostlog-badge';
      badge.setAttribute('data-ghostlog-ghost', '1');
      // an absolutely positioned badge needs a positioned host
      if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
      el.appendChild(badge);
    }
    const text = count > 99 ? '99+' : String(count);
    if (badge.textContent !== text) badge.textContent = text;
    badge.title = `${count} message${count === 1 ? '' : 's'} deleted while you were away`;
  }

  function clearBadges() {
    for (const b of document.querySelectorAll('.ghostlog-badge')) b.remove();
  }

  let lastBadgeCounts = '';

  async function refreshBadges() {
    if (!settings.enabled || !settings.sidebarBadges || settings.stealth) {
      clearBadges();
      lastBadgeCounts = '';
      return;
    }
    const res = await send('badge:counts');
    if (!res || !res.ok || !res.result) return;
    const { byChannel = {}, byGuild = {} } = res.result;

    // Walking the sidebar means a document-wide query and a style read per
    // badge. Skip it entirely when the numbers have not moved, which is the
    // overwhelmingly common case.
    const signature = JSON.stringify([byChannel, byGuild]);
    const anyBadges = document.querySelector('.ghostlog-badge');
    if (signature === lastBadgeCounts && anyBadges) return;
    if (signature === '[{},{}]' && !anyBadges) { lastBadgeCounts = signature; return; }
    lastBadgeCounts = signature;

    for (const target of sidebarTargets()) {
      const count = target.kind === 'guild'
        ? (byGuild[target.id] || 0)
        : (byChannel[target.id] || 0);
      paintBadge(target.el, count);
    }
  }

  function startBadgeLoop() {
    clearInterval(badgeTimer);
    badgeTimer = setInterval(refreshBadges, 12000);
    refreshBadges();
  }

  // -------------------------------------------------------------------------
  // observers
  // -------------------------------------------------------------------------

  function findList() {
    return document.querySelector('ol[data-list-id="chat-messages"]');
  }

  function attachObservers(ol) {
    if (listObserver) listObserver.disconnect();
    if (editObserver) editObserver.disconnect();
    if (idObserver) idObserver.disconnect();
    listEl = ol;

    // a new list means our previous ghost nodes are detached; forget them so
    // the backfill can draw them again
    for (const [id, node] of [...ghostNodes]) {
      if (!node.isConnected) ghostNodes.delete(id);
    }

    listObserver = new MutationObserver((records) => {
      let grew = false;
      for (const rec of records) {
        for (const node of rec.addedNodes) {
          if (node.nodeType === 1 && isMessageNode(node)) { ingest(node); grew = true; }
        }
        for (const node of rec.removedNodes) {
          if (node.nodeType === 1 && isMessageNode(node)) onRemoved(node, rec);
        }
      }
      if (grew) {
        retryDeferredGhosts(); // older history may have rendered the missing slot
        scheduleBackfill();
      }
    });
    listObserver.observe(ol, { childList: true });

    // watch for a message id being rewritten in place (a confirmed send)
    idObserver = new MutationObserver((records) => {
      for (const rec of records) {
        if (rec.attributeName === 'id') handleIdSwap(rec.target, rec.oldValue);
      }
    });
    idObserver.observe(ol, {
      subtree: true, attributes: true, attributeFilter: ['id'], attributeOldValue: true
    });

    if (settings.logEdits) {
      editObserver = new MutationObserver((records) => {
        for (const rec of records) {
          const start = rec.type === 'characterData' ? rec.target.parentElement : rec.target;
          if (!start || start.nodeType !== 1) continue;
          const content = start.closest ? start.closest('[id^="message-content-"]') : null;
          if (content) onContentMutated(content);
        }
      });
      editObserver.observe(ol, { subtree: true, childList: true, characterData: true });
    }

    // pick up everything already on screen
    for (const li of ol.children) {
      if (li.nodeType === 1 && isMessageNode(li)) ingest(li);
    }

    // a new list element means a fresh render — the moment to surface anything
    // that was deleted while this channel was not open
    scheduleBackfill({ force: true, immediate: true });
  }

  function ensureAttached() {
    const ol = findList();
    if (ol && ol !== listEl) attachObservers(ol);
    else if (!ol && listEl) { listEl = null; }
  }

  // -------------------------------------------------------------------------
  // settings plumbing
  // -------------------------------------------------------------------------

  function applyVisualSettings() {
    const root = document.documentElement;

    // stealth leaves zero trace in the page: no attributes, no nodes, no styles
    if (settings.stealth) {
      root.style.removeProperty('--ghostlog-accent');
      root.removeAttribute('data-ghostlog-timestamps');
      root.removeAttribute('data-ghostlog-active');
      for (const [, node] of ghostNodes) node.remove();
      ghostNodes.clear();
      for (const el of document.querySelectorAll('[data-ghostlog-hit], [data-ghostlog-edits]')) {
        el.removeAttribute('data-ghostlog-hit');
        el.removeAttribute('data-ghostlog-edits');
      }
      if (counterEl) { counterEl.remove(); counterEl = null; }
      clearBadges();
      return;
    }

    root.style.setProperty('--ghostlog-accent', settings.accent || DEFAULTS.accent);
    root.setAttribute('data-ghostlog-timestamps', settings.alwaysTimestamps ? '1' : '0');
    root.setAttribute('data-ghostlog-active', settings.enabled ? '1' : '0');
    if (!settings.enabled) {
      for (const [, node] of ghostNodes) node.remove();
      ghostNodes.clear();
    }
    rescanKeywords();
    updateCounter();
    lastBadgeCounts = '';
    refreshBadges();
  }

  async function loadSettings() {
    const res = await send('settings:get');
    if (res && res.ok) settings = { ...DEFAULTS, ...res.result };
    applyVisualSettings();
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'settings:changed') {
      const wasEdits = settings.logEdits;
      settings = { ...DEFAULTS, ...msg.payload };
      applyVisualSettings();
      if (wasEdits !== settings.logEdits && listEl) attachObservers(listEl);
    }
  });

  // -------------------------------------------------------------------------
  // boot
  // -------------------------------------------------------------------------

  const markScroll = () => { lastUserScrollTs = Date.now(); };
  document.addEventListener('wheel', markScroll, { capture: true, passive: true });
  document.addEventListener('touchmove', markScroll, { capture: true, passive: true });
  document.addEventListener('mousedown', markScroll, { capture: true, passive: true });
  document.addEventListener('keydown', (e) => {
    if (['PageUp', 'PageDown', 'Home', 'End', 'ArrowUp', 'ArrowDown'].includes(e.key)) markScroll();
  }, { capture: true, passive: true });

  window.addEventListener('beforeunload', flush);
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });

  refreshRoute();
  loadSettings();
  ensureAttached();
  if (route.channelId) send('badge:ack', { channelId: route.channelId });
  startBadgeLoop();

  // Discord is a SPA: poll for navigation and for the list being rebuilt.
  setInterval(() => {
    if (refreshRoute()) { listEl = null; }
    ensureAttached();
  }, 500);

  console.info('[GhostLog] watching this tab — local only, no network calls.');
})();
