const $ = (id) => document.getElementById(id);

function send(type, payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, payload }, (res) => {
      void chrome.runtime.lastError;
      resolve(res && res.ok ? res.result : null);
    });
  });
}

const PAGE = 250;

const state = {
  rows: [],
  cursor: null,
  loading: false,
  filters: {
    search: '', guildId: '', channelId: '', authorId: '',
    deletedOnly: false, editedOnly: false, from: null, to: null
  }
};

// ---------------------------------------------------------------- format ---

const dtf = new Intl.DateTimeFormat(undefined, {
  year: 'numeric', month: 'short', day: '2-digit'
});
const tf = new Intl.DateTimeFormat(undefined, {
  hour: '2-digit', minute: '2-digit', second: '2-digit'
});

function fmtDate(ms) { return dtf.format(new Date(ms)); }
function fmtTime(ms) { return tf.format(new Date(ms)); }

function relative(ms) {
  const diff = Date.now() - ms;
  const mins = Math.round(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

/** Build a text node run with the search needle wrapped in <mark>. */
function highlight(text, needle) {
  const frag = document.createDocumentFragment();
  if (!needle) { frag.appendChild(document.createTextNode(text)); return frag; }
  const lower = text.toLowerCase();
  const n = needle.toLowerCase();
  let i = 0;
  while (true) {
    const hit = lower.indexOf(n, i);
    if (hit === -1) { frag.appendChild(document.createTextNode(text.slice(i))); break; }
    frag.appendChild(document.createTextNode(text.slice(i, hit)));
    const mark = document.createElement('mark');
    mark.textContent = text.slice(hit, hit + n.length);
    frag.appendChild(mark);
    i = hit + n.length;
  }
  return frag;
}

// ------------------------------------------------------------------ rows ---

function buildRow(r) {
  const el = document.createElement('div');
  el.className = 'row';
  if (r.deletedAt) el.classList.add('deleted');
  else if (r.edits && r.edits.length) el.classList.add('edited');
  el.tabIndex = 0;

  // date
  const date = document.createElement('span');
  date.className = 'c-date';
  date.append(document.createTextNode(`${fmtDate(r.ts)} ${fmtTime(r.ts)}`));
  if (r.deletedAt) {
    const sub = document.createElement('small');
    // an inferred delete was noticed on return, so the time is when we spotted
    // it, not when it happened
    sub.textContent = r.inferredDelete
      ? `found gone ${relative(r.deletedAt)}`
      : `deleted ${relative(r.deletedAt)}`;
    date.appendChild(sub);
  }

  // author
  const who = document.createElement('span');
  who.className = 'c-who';
  if (r.avatar) {
    const img = document.createElement('img');
    img.src = r.avatar;
    img.alt = '';
    img.loading = 'lazy';
    img.addEventListener('error', () => img.remove());
    who.appendChild(img);
  }
  const names = document.createElement('span');
  names.className = 'names';
  const name = document.createElement('span');
  name.className = 'name';
  name.appendChild(highlight(r.authorName || 'Unknown', state.filters.search));
  const uid = document.createElement('span');
  uid.className = 'uid';
  uid.textContent = r.authorId || 'id unknown';
  names.append(name, uid);
  who.appendChild(names);

  // channel
  const where = document.createElement('span');
  where.className = 'c-where';
  const ch = document.createElement('div');
  ch.className = 'ch';
  ch.textContent = r.channelName ? `#${r.channelName}` : (r.channelId || '');
  const gu = document.createElement('div');
  gu.className = 'gu';
  gu.textContent = r.guildName || (r.guildId ? r.guildId : 'Direct Messages');
  where.append(ch, gu);

  // message
  const msg = document.createElement('span');
  msg.className = 'c-msg';
  if (r.deletedAt) {
    const t = document.createElement('span');
    t.className = 'tag del';
    t.textContent = 'deleted';
    msg.appendChild(t);
  }
  if (r.edits && r.edits.length) {
    const t = document.createElement('span');
    t.className = 'tag edt';
    t.textContent = `edited ${r.edits.length}×`;
    msg.appendChild(t);
  }
  if (r.bot) {
    const t = document.createElement('span');
    t.className = 'tag bot';
    t.textContent = 'bot';
    msg.appendChild(t);
  }
  msg.appendChild(highlight(r.content || '(no text)', state.filters.search));
  if (r.attachments && r.attachments.length) {
    const kinds = r.attachments.map((a) => a.kind);
    const icon = kinds.includes('image') ? '🖼' : kinds.includes('video') ? '🎬'
      : kinds.includes('audio') ? '🎵' : '📎';
    const att = document.createElement('span');
    att.className = 'att';
    att.textContent = `${icon} ${r.attachments.length} attachment${r.attachments.length > 1 ? 's' : ''}`;
    msg.appendChild(att);
  }

  el.append(date, who, where, msg);
  el.addEventListener('click', () => openSheet(r));
  el.addEventListener('keydown', (e) => { if (e.key === 'Enter') openSheet(r); });
  return el;
}

function render(append) {
  const box = $('rows');
  if (!append) box.textContent = '';
  const frag = document.createDocumentFragment();
  const slice = append ? state.rows.slice(box.children.length) : state.rows;
  for (const r of slice) frag.appendChild(buildRow(r));
  box.appendChild(frag);

  $('cShown').textContent = state.rows.length.toLocaleString();
  $('empty').hidden = state.rows.length > 0;
  $('loadMore').hidden = state.cursor === null;
  $('status').textContent = state.cursor === null && state.rows.length ? 'End of archive.' : '';
}

// ----------------------------------------------------------------- query ---

async function load(append) {
  if (state.loading) return;
  state.loading = true;
  $('status').textContent = 'Loading…';

  const res = await send('query', {
    limit: PAGE,
    before: append ? state.cursor : null,
    ...state.filters
  });

  state.loading = false;
  if (!res) { $('status').textContent = 'Could not read the archive.'; return; }

  state.rows = append ? state.rows.concat(res.rows) : res.rows;
  state.cursor = res.nextCursor;
  render(append);
}

function readFilters() {
  const fromVal = $('from').value;
  const toVal = $('to').value;
  state.filters = {
    search: $('search').value,
    guildId: $('guild').value,
    channelId: $('channel').value,
    authorId: $('author').value,
    deletedOnly: $('deletedOnly').checked,
    editedOnly: $('editedOnly').checked,
    from: fromVal ? new Date(`${fromVal}T00:00:00`).getTime() : null,
    to: toVal ? new Date(`${toVal}T23:59:59`).getTime() : null
  };
  state.cursor = null;
  load(false);
}

// ----------------------------------------------------------------- sheet ---

function openSheet(r) {
  const body = $('sheetBody');
  body.textContent = '';

  const h = document.createElement('h2');
  h.textContent = r.authorName || 'Unknown';
  const sub = document.createElement('div');
  sub.className = 'sub';
  sub.textContent = `${fmtDate(r.ts)} at ${fmtTime(r.ts)} · ${r.channelName ? '#' + r.channelName : 'unknown channel'} · ${r.guildName || 'Direct Messages'}`;

  const content = document.createElement('div');
  content.className = 'body';
  content.textContent = r.content || '(no text content)';

  body.append(h, sub, content);

  if (r.edits && r.edits.length) {
    const t = document.createElement('h3');
    t.textContent = `Previous versions (${r.edits.length})`;
    body.appendChild(t);
    for (const e of [...r.edits].reverse()) {
      const v = document.createElement('div');
      v.className = 'ver';
      const s = document.createElement('small');
      s.textContent = `${fmtDate(e.at)} ${fmtTime(e.at)}`;
      v.append(s, document.createTextNode(e.content));
      body.appendChild(v);
    }
  }

  if (r.reply && (r.reply.authorName || r.reply.content)) {
    const t = document.createElement('h3');
    t.textContent = 'In reply to';
    const v = document.createElement('div');
    v.className = 'ver';
    v.textContent = `${r.reply.authorName || '?'}: ${r.reply.content || ''}`;
    body.append(t, v);
  }

  if (r.attachments && r.attachments.length) {
    const t = document.createElement('h3');
    t.textContent = `Attachments (${r.attachments.length})`;
    body.appendChild(t);
    const holder = document.createElement('div');
    holder.className = 'media';
    holder.textContent = 'Loading saved files…';
    body.appendChild(holder);
    renderMedia(holder, r);
  }

  const t2 = document.createElement('h3');
  t2.textContent = 'Details';
  const dl = document.createElement('dl');
  const pairs = [
    ['Message ID', r.id],
    ['Author ID', r.authorId || 'unknown'],
    ['Channel ID', r.channelId || 'unknown'],
    ['Server ID', r.guildId || 'DM'],
    ['Sent', new Date(r.ts).toString()],
    ['Deleted', r.deletedAt
      ? (r.inferredDelete
        ? `noticed missing ${new Date(r.deletedAt).toString()} (deleted at some point while you were away)`
        : new Date(r.deletedAt).toString())
      : 'no'],
    ['First seen', r.firstSeen ? new Date(r.firstSeen).toString() : 'unknown']
  ];
  for (const [k, v] of pairs) {
    const dt = document.createElement('dt'); dt.textContent = k;
    const dd = document.createElement('dd'); dd.textContent = v;
    dl.append(dt, dd);
  }
  body.append(t2, dl);

  const btns = document.createElement('div');
  btns.className = 'rowbtns';

  const copy = document.createElement('button');
  copy.textContent = 'Copy text';
  copy.onclick = () => { navigator.clipboard.writeText(r.content || ''); copy.textContent = 'Copied'; };

  const jump = document.createElement('button');
  jump.textContent = 'Open in Discord';
  jump.onclick = () => {
    const g = r.guildId || '@me';
    window.open(`https://discord.com/channels/${g}/${r.channelId}/${r.id}`, '_blank', 'noreferrer');
  };

  const byAuthor = document.createElement('button');
  byAuthor.textContent = 'All from this author';
  byAuthor.onclick = () => {
    $('author').value = r.authorId || '';
    closeSheet();
    readFilters();
  };

  btns.append(copy, jump, byAuthor);
  body.appendChild(btns);

  $('sheet').hidden = false;
}

function closeSheet() { $('sheet').hidden = true; }

function humanBytes(n) {
  if (!n) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n < 10 ? n.toFixed(1) : Math.round(n)} ${units[i]}`;
}

/**
 * Show the bytes the archive actually kept. The original CDN link is signed and
 * expires, so it is offered only as a long shot after the saved copy.
 */
/** Pull one file's bytes and swap it in for its button. */
async function showMediaItem(box, slot, item, cap) {
  slot.textContent = 'Loading…';
  slot.disabled = true;
  const full = await send('media:one', { id: item.id });
  if (!full || full.missing || !full.dataUrl) { slot.textContent = 'Could not load'; return; }

  let el;
  if (full.kind === 'image') { el = document.createElement('img'); el.alt = item.name || ''; }
  else if (full.kind === 'video') { el = document.createElement('video'); el.controls = true; }
  else if (full.kind === 'audio') { el = document.createElement('audio'); el.controls = true; }
  else { slot.textContent = 'Cannot preview this type'; return; }

  el.src = full.dataUrl;
  el.preload = 'metadata';
  slot.replaceWith(el);
  box.insertBefore(el, cap);

  const dl = document.createElement('a');
  dl.href = full.dataUrl;
  dl.download = item.name || 'attachment';
  dl.textContent = 'Save file';
  dl.className = 'media__dl';
  cap.append(' · ', dl);
}

async function renderMedia(holder, r) {
  const res = await send('media:for', { messageId: r.id });
  const saved = (res && res.media) || [];
  const byKey = new Map(saved.map((m) => [m.id, m]));
  holder.textContent = '';

  for (const a of r.attachments) {
    const item = byKey.get(a.url.split('?')[0]);
    const box = document.createElement('figure');
    box.className = 'media__item';

    const cap = document.createElement('figcaption');
    if (item) {
      // The listing carries names and sizes only; the bytes are fetched per
      // file, so opening a message with a large video is not a stall.
      const slot = document.createElement('button');
      slot.className = 'media__load';
      slot.textContent = `Load ${item.kind} · ${humanBytes(item.size)}`;
      slot.addEventListener('click', () => showMediaItem(box, slot, item, cap));
      box.appendChild(slot);
      if (item.kind === 'image' && item.size <= 3 * 1048576) showMediaItem(box, slot, item, cap);

      cap.textContent = `${item.name || item.kind} · ${humanBytes(item.size)} · saved`;
    } else {
      cap.textContent = `${a.name || a.kind} · not saved`;
      const orig = document.createElement('a');
      orig.href = a.url;
      orig.target = '_blank';
      orig.rel = 'noreferrer noopener';
      orig.textContent = 'try the original link';
      orig.className = 'media__dl';
      cap.append(' · ', orig);
    }
    box.appendChild(cap);
    holder.appendChild(box);
  }

  if (!r.attachments.length) holder.textContent = 'None.';
}

// ---------------------------------------------------------------- export ---

function download(filename, text, mime) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function csvCell(v) {
  const s = v == null ? '' : String(v);
  return `"${s.replace(/"/g, '""')}"`;
}

async function doExport(format) {
  $('status').textContent = 'Preparing export…';
  const res = await send('export', { format });
  if (!res) { $('status').textContent = 'Export failed.'; return; }
  const stamp = new Date().toISOString().slice(0, 10);

  if (format === 'json') {
    download(`ghostlog-${stamp}.json`, JSON.stringify(res.rows, null, 2), 'application/json');
  } else {
    const head = ['date', 'time', 'author', 'author_id', 'server', 'channel', 'message', 'deleted', 'deleted_at', 'edits', 'message_id'];
    const lines = [head.join(',')];
    for (const r of res.rows) {
      lines.push([
        fmtDate(r.ts), fmtTime(r.ts), r.authorName, r.authorId,
        r.guildName || 'DM', r.channelName, r.content,
        r.deletedAt ? 'yes' : 'no',
        r.deletedAt ? new Date(r.deletedAt).toISOString() : '',
        (r.edits || []).length, r.id
      ].map(csvCell).join(','));
    }
    download(`ghostlog-${stamp}.csv`, lines.join('\n'), 'text/csv');
  }
  $('status').textContent = `Exported ${res.rows.length.toLocaleString()} records.`;
}

// ------------------------------------------------------------------ init ---

async function fillFacets() {
  const f = await send('facets');
  if (!f) return;

  const guild = $('guild');
  for (const g of f.guilds.sort((a, b) => a.name.localeCompare(b.name))) {
    const o = document.createElement('option');
    o.value = g.id; o.textContent = g.name;
    guild.appendChild(o);
  }

  const channel = $('channel');
  const paintChannels = () => {
    const picked = guild.value;
    channel.textContent = '';
    const all = document.createElement('option');
    all.value = ''; all.textContent = 'All channels';
    channel.appendChild(all);
    for (const c of f.channels.filter((c) => !picked || c.guildId === picked).sort((a, b) => a.name.localeCompare(b.name))) {
      const o = document.createElement('option');
      o.value = c.id; o.textContent = `#${c.name}`;
      channel.appendChild(o);
    }
  };
  paintChannels();
  guild.addEventListener('change', () => { paintChannels(); readFilters(); });

  const author = $('author');
  for (const a of f.authors.sort((x, y) => x.name.localeCompare(y.name))) {
    const o = document.createElement('option');
    o.value = a.id; o.textContent = a.name;
    author.appendChild(o);
  }

  // deep link from the in-chat counter: viewer.html#channel=123
  const m = /channel=(\d+)/.exec(location.hash);
  if (m) {
    channel.value = m[1];
    $('deletedOnly').checked = true;
    readFilters();
  }
}

async function refreshCounts() {
  const s = await send('stats');
  if (!s) return;
  $('cTotal').textContent = s.total.toLocaleString();
  $('cDeleted').textContent = s.deleted.toLocaleString();
  const usage = await send('media:usage');
  if (usage && typeof usage.count === 'number') {
    $('cMedia').textContent = `${usage.count.toLocaleString()} files · ${humanBytes(usage.bytes || 0)}`;
  }
}

function init() {
  // wire the notice unconditionally so dismissal never depends on how it opened
  const welcome = $('welcome');
  const closeWelcome = () => { welcome.hidden = true; };
  welcome.hidden = !location.hash.includes('welcome');
  $('welcomeClose').addEventListener('click', closeWelcome);
  welcome.addEventListener('click', (e) => { if (e.target === welcome) closeWelcome(); });

  let t;
  $('search').addEventListener('input', () => { clearTimeout(t); t = setTimeout(readFilters, 260); });
  for (const id of ['channel', 'author', 'from', 'to', 'deletedOnly', 'editedOnly']) {
    $(id).addEventListener('change', readFilters);
  }
  $('reset').addEventListener('click', () => {
    $('search').value = '';
    for (const id of ['guild', 'channel', 'author']) $(id).value = '';
    for (const id of ['from', 'to']) $(id).value = '';
    $('deletedOnly').checked = false;
    $('editedOnly').checked = false;
    readFilters();
  });

  $('forget').addEventListener('click', async () => {
    const btn = $('forget');
    const channelId = $('channel').value;
    const guildId = $('guild').value;
    if (!channelId && !guildId) { $('status').textContent = 'Pick a server or channel first.'; return; }

    const label = channelId ? $('channel').selectedOptions[0].textContent : $('guild').selectedOptions[0].textContent;
    if (btn.dataset.armed !== '1') {
      btn.dataset.armed = '1';
      btn.textContent = `Really forget ${label}?`;
      setTimeout(() => { btn.dataset.armed = '0'; btn.textContent = 'Forget selection'; }, 4500);
      return;
    }

    const res = channelId
      ? await send('purge:channel', { channelId })
      : await send('purge:guild', { guildId });
    btn.dataset.armed = '0';
    btn.textContent = 'Forget selection';
    $('status').textContent = `Deleted ${(res?.removed || 0).toLocaleString()} records from ${label}.`;
    refreshCounts();
    readFilters();
  });

  $('loadMore').addEventListener('click', () => load(true));
  $('exportJson').addEventListener('click', () => doExport('json'));
  $('exportCsv').addEventListener('click', () => doExport('csv'));
  $('sheetClose').addEventListener('click', closeSheet);
  $('sheet').addEventListener('click', (e) => { if (e.target === $('sheet')) closeSheet(); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { closeSheet(); closeWelcome(); }
    if (e.key === '/' && document.activeElement !== $('search')) { e.preventDefault(); $('search').focus(); }
  });

  fillFacets();
  refreshCounts();
  load(false);
  setInterval(refreshCounts, 8000);
}

init();
