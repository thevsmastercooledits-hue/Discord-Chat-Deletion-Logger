// Shared default settings. Loaded by the service worker, popup and viewer.
// Content script keeps its own inlined copy (content scripts can't use modules).
export const DEFAULTS = {
  enabled: true,            // master switch
  ghostsInline: true,       // re-insert deleted messages into the chat
  logEdits: true,           // keep previous versions of edited messages
  strictMode: false,        // only ghost a deletion when both neighbours survived
  stealth: false,           // archive silently: touch nothing in the page at all
  backfill: true,           // on opening a channel, surface deletions you missed
  debug: false,             // narrate every decision to the page console
  sidebarBadges: true,      // purple count on servers/DMs for away-deletions
  alwaysTimestamps: true,   // show the time on grouped messages too
  accent: '#ed4245',        // ghost tint
  ghostFade: 0,             // seconds before a ghost auto-hides (0 = never)
  keywords: [],             // highlight + notify on these words
  notifyKeywords: false,
  ignoredGuilds: [],        // guild ids never logged
  ignoreDMs: false,
  storeMedia: 'deleted',    // 'off' | 'deleted' | 'all' — keep attachment bytes
  mediaMaxImageMB: 8,       // per-file caps
  mediaMaxAudioMB: 12,
  mediaMaxVideoMB: 25,
  mediaBudgetMB: 500,       // total media store; oldest evicted past this
  retentionDays: 30,        // prune records older than this (0 = keep forever)
  maxRecords: 50000         // hard cap, oldest pruned first (0 = unlimited)
};

export async function getSettings() {
  const stored = await chrome.storage.local.get('settings');
  return { ...DEFAULTS, ...(stored.settings || {}) };
}

export async function setSettings(patch) {
  const current = await getSettings();
  const next = { ...current, ...patch };
  await chrome.storage.local.set({ settings: next });
  return next;
}
