// IndexedDB store for GhostLog. Lives in the extension origin, so clearing
// Discord's site data never touches the archive.

const DB_NAME = 'ghostlog';
const DB_VERSION = 3;
const STORE = 'messages';
const MEDIA = 'media';

let dbPromise = null;

export function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: 'id' });
        store.createIndex('by_ts', 'ts');
        store.createIndex('by_guild', 'guildId');
        store.createIndex('by_channel', 'channelId');
        store.createIndex('by_author', 'authorId');
        // sparse: only records that actually got deleted carry deletedAt
        store.createIndex('by_deleted', 'deletedAt');
        store.createIndex('by_channel_ts', ['channelId', 'ts']);
      }
      // v3: the gap scan asks for one channel within a time range. Without a
      // compound index that is a full walk of every message in the channel,
      // repeated on every scan — the single biggest cost in the extension.
      if (db.objectStoreNames.contains(STORE)) {
        const store = req.transaction.objectStore(STORE);
        if (!store.indexNames.contains('by_channel_ts')) {
          store.createIndex('by_channel_ts', ['channelId', 'ts']);
        }
      }
      // v2: attachment bytes, so a deleted image still has something to show
      // once Discord's signed CDN link has expired
      if (!db.objectStoreNames.contains(MEDIA)) {
        const media = db.createObjectStore(MEDIA, { keyPath: 'id' });
        media.createIndex('by_message', 'messageId');
        media.createIndex('by_saved', 'savedAt');
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

function tx(store, mode) {
  return openDB().then((db) => db.transaction(store, mode).objectStore(store));
}

function wrap(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Insert or merge a message record. A re-render of a message that was already
 * marked deleted must never resurrect it as "alive".
 */
export async function upsertMessage(record) {
  const store = await tx(STORE, 'readwrite');
  const existing = await wrap(store.get(record.id));
  if (!existing) {
    await wrap(store.put(record));
    return { created: true };
  }
  const merged = {
    ...existing,
    ...record,
    deletedAt: existing.deletedAt ?? record.deletedAt ?? undefined,
    edits: existing.edits && existing.edits.length ? existing.edits : record.edits,
    firstSeen: existing.firstSeen ?? record.firstSeen
  };
  if (merged.deletedAt === undefined) delete merged.deletedAt;
  await wrap(store.put(merged));
  return { created: false };
}

export async function markDeleted(id, deletedAt, inferred) {
  const store = await tx(STORE, 'readwrite');
  const existing = await wrap(store.get(id));
  if (!existing) return false;
  if (existing.deletedAt) return false;
  existing.deletedAt = deletedAt;
  // "inferred" means we found it missing on return rather than watching it go,
  // so deletedAt is when we noticed, not when it happened.
  if (inferred) existing.inferredDelete = true;
  await wrap(store.put(existing));
  return true;
}

/**
 * Messages this channel has archived inside the given time span that are no
 * longer on screen — i.e. deleted while the user was not watching. Bounded by
 * the rendered window, so a gap can only be claimed between two messages that
 * are both still present.
 */
/**
 * Deletions already recorded for this channel inside the rendered span. These
 * are redrawn on every load so a ghost survives a refresh instead of vanishing
 * the moment the page reloads.
 */
export async function findDeletedInRange(channelId, minTs, maxTs, limit = 200) {
  const store = await tx(STORE, 'readonly');
  const index = store.index('by_channel_ts');
  const range = IDBKeyRange.bound([channelId, minTs], [channelId, maxTs]);
  const out = [];

  await new Promise((resolve, reject) => {
    const req = index.openCursor(range);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor || out.length >= limit) return resolve();
      if (cursor.value.deletedAt) out.push(cursor.value);
      cursor.continue();
    };
  });

  out.sort((a, b) => a.ts - b.ts);
  return out;
}

/**
 * Unacknowledged "deleted while you were away" counts, per channel and per
 * guild, for the sidebar badges. `acks` maps channelId -> timestamp last seen.
 */
export async function awayCounts(acks = {}) {
  const store = await tx(STORE, 'readonly');
  const byChannel = {};
  const byGuild = {};

  await new Promise((resolve, reject) => {
    const req = store.index('by_deleted').openCursor();
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor) return resolve();
      const r = cursor.value;
      if (r.inferredDelete && r.channelId) {
        const since = acks[r.channelId] || 0;
        if (r.deletedAt > since) {
          byChannel[r.channelId] = (byChannel[r.channelId] || 0) + 1;
          const g = r.guildId || '@me';
          byGuild[g] = (byGuild[g] || 0) + 1;
        }
      }
      cursor.continue();
    };
  });

  return { byChannel, byGuild };
}

export async function findGaps(channelId, minTs, maxTs, presentIds, limit = 50) {
  const store = await tx(STORE, 'readonly');
  const index = store.index('by_channel_ts');
  const range = IDBKeyRange.bound([channelId, minTs], [channelId, maxTs]);
  const present = new Set(presentIds);
  const out = [];

  await new Promise((resolve, reject) => {
    const req = index.openCursor(range);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor || out.length >= limit) return resolve();
      const r = cursor.value;
      if (!r.deletedAt && !present.has(r.id)) out.push(r);
      cursor.continue();
    };
  });

  out.sort((a, b) => a.ts - b.ts);
  return out;
}

export async function appendEdit(id, previousContent, at) {
  const store = await tx(STORE, 'readwrite');
  const existing = await wrap(store.get(id));
  if (!existing) return false;
  existing.edits = existing.edits || [];
  const last = existing.edits[existing.edits.length - 1];
  if (last && last.content === previousContent) return false;
  existing.edits.push({ content: previousContent, at });
  await wrap(store.put(existing));
  return true;
}

/**
 * Newest-first page of records, filtered inside the cursor so the viewer never
 * has to hold the whole archive in memory.
 */
export async function queryMessages(opts = {}) {
  const {
    limit = 300, before = null, guildId = null, channelId = null,
    authorId = null, deletedOnly = false, editedOnly = false,
    search = '', from = null, to = null
  } = opts;

  const store = await tx(STORE, 'readonly');
  const index = store.index('by_ts');
  const upper = before != null ? before - 1 : (to != null ? to : null);
  let range = null;
  if (upper != null && from != null) range = IDBKeyRange.bound(from, upper);
  else if (upper != null) range = IDBKeyRange.upperBound(upper);
  else if (from != null) range = IDBKeyRange.lowerBound(from);

  const needle = search.trim().toLowerCase();
  const out = [];
  let scanned = 0;

  await new Promise((resolve, reject) => {
    const req = index.openCursor(range, 'prev');
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor || out.length >= limit) return resolve();
      scanned++;
      const r = cursor.value;
      let ok = true;
      if (guildId && r.guildId !== guildId) ok = false;
      if (ok && channelId && r.channelId !== channelId) ok = false;
      if (ok && authorId && r.authorId !== authorId) ok = false;
      if (ok && deletedOnly && !r.deletedAt) ok = false;
      if (ok && editedOnly && !(r.edits && r.edits.length)) ok = false;
      if (ok && needle) {
        const hay = ((r.content || '') + ' ' + (r.authorName || '') + ' ' + (r.channelName || '')).toLowerCase();
        if (!hay.includes(needle)) ok = false;
      }
      if (ok) out.push(r);
      // never let a pathological search walk the whole archive in one pass
      if (scanned > 40000) return resolve();
      cursor.continue();
    };
  });

  const nextCursor = out.length === limit ? out[out.length - 1].ts : null;
  return { rows: out, nextCursor };
}

export async function countAll() {
  const store = await tx(STORE, 'readonly');
  return wrap(store.count());
}

export async function countDeleted() {
  const store = await tx(STORE, 'readonly');
  return wrap(store.index('by_deleted').count());
}

/** Distinct guilds/channels/authors seen, for the viewer filter dropdowns. */
export async function facets() {
  const store = await tx(STORE, 'readonly');
  const guilds = new Map();
  const channels = new Map();
  const authors = new Map();
  await new Promise((resolve, reject) => {
    const req = store.index('by_ts').openCursor(null, 'prev');
    req.onerror = () => reject(req.error);
    let n = 0;
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor || n > 20000) return resolve();
      n++;
      const r = cursor.value;
      if (r.guildId && !guilds.has(r.guildId)) guilds.set(r.guildId, r.guildName || r.guildId);
      if (r.channelId && !channels.has(r.channelId)) {
        channels.set(r.channelId, { name: r.channelName || r.channelId, guildId: r.guildId });
      }
      if (r.authorId && !authors.has(r.authorId)) authors.set(r.authorId, r.authorName || r.authorId);
      cursor.continue();
    };
  });
  return {
    guilds: [...guilds].map(([id, name]) => ({ id, name })),
    channels: [...channels].map(([id, v]) => ({ id, name: v.name, guildId: v.guildId })),
    authors: [...authors].map(([id, name]) => ({ id, name }))
  };
}

export async function deleteWhere(predicate) {
  const store = await tx(STORE, 'readwrite');
  let removed = 0;
  await new Promise((resolve, reject) => {
    const req = store.openCursor();
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor) return resolve();
      if (predicate(cursor.value)) { cursor.delete(); removed++; }
      cursor.continue();
    };
  });
  return removed;
}

/** Drop one record — used to clean up a temporary send id. */
export async function deleteById(id) {
  const store = await tx(STORE, 'readwrite');
  await wrap(store.delete(id));
  return true;
}

export async function clearAll() {
  const store = await tx(STORE, 'readwrite');
  await wrap(store.clear());
}

export async function exportAll() {
  const store = await tx(STORE, 'readonly');
  return wrap(store.getAll());
}

/** Retention: drop anything older than retentionDays, then trim to maxRecords. */
export async function prune(opts) {
  const retentionDays = opts.retentionDays;
  const maxRecords = opts.maxRecords;
  let removed = 0;

  if (retentionDays > 0) {
    const cutoff = Date.now() - retentionDays * 86400000;
    const store = await tx(STORE, 'readwrite');
    await new Promise((resolve, reject) => {
      const req = store.index('by_ts').openCursor(IDBKeyRange.upperBound(cutoff));
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        const cursor = req.result;
        if (!cursor) return resolve();
        cursor.delete(); removed++;
        cursor.continue();
      };
    });
  }

  if (maxRecords > 0) {
    const total = await countAll();
    let excess = total - maxRecords;
    if (excess > 0) {
      const store = await tx(STORE, 'readwrite');
      await new Promise((resolve, reject) => {
        const req = store.index('by_ts').openCursor(null, 'next');
        req.onerror = () => reject(req.error);
        req.onsuccess = () => {
          const cursor = req.result;
          if (!cursor || excess <= 0) return resolve();
          cursor.delete(); removed++; excess--;
          cursor.continue();
        };
      });
    }
  }

  return removed;
}

// ---------------------------------------------------------------------------
// media
// ---------------------------------------------------------------------------

/** Stable key for an attachment: the CDN path, minus the expiring signature. */
export function mediaKey(url) {
  try {
    const u = new URL(url);
    return u.origin + u.pathname;
  } catch {
    return url;
  }
}

export async function putMedia(record) {
  const store = await tx(MEDIA, 'readwrite');
  await wrap(store.put(record));
  return true;
}

export async function getMedia(id) {
  const store = await tx(MEDIA, 'readonly');
  return wrap(store.get(id));
}

export async function hasMedia(id) {
  const store = await tx(MEDIA, 'readonly');
  const key = await wrap(store.getKey(id));
  return key !== undefined;
}

export async function mediaForMessage(messageId) {
  const store = await tx(MEDIA, 'readonly');
  return wrap(store.index('by_message').getAll(messageId));
}

export async function mediaUsage() {
  const store = await tx(MEDIA, 'readonly');
  let bytes = 0;
  let count = 0;
  await new Promise((resolve, reject) => {
    const req = store.openCursor();
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor) return resolve();
      bytes += cursor.value.size || 0;
      count++;
      cursor.continue();
    };
  });
  return { bytes, count };
}

/** Evict oldest media until the store fits the budget. */
export async function pruneMedia(budgetBytes) {
  if (!budgetBytes || budgetBytes <= 0) return 0;
  const { bytes } = await mediaUsage();
  let excess = bytes - budgetBytes;
  if (excess <= 0) return 0;

  const store = await tx(MEDIA, 'readwrite');
  let removed = 0;
  await new Promise((resolve, reject) => {
    const req = store.index('by_saved').openCursor();
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor || excess <= 0) return resolve();
      excess -= cursor.value.size || 0;
      cursor.delete();
      removed++;
      cursor.continue();
    };
  });
  return removed;
}

export async function clearMedia() {
  const store = await tx(MEDIA, 'readwrite');
  await wrap(store.clear());
}
