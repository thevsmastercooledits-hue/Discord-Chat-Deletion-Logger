# GhostLog for Discord

A Chrome extension that keeps a local, searchable record of the Discord messages
your client renders — and when someone deletes a message, keeps it visible in the
chat instead of letting it vanish.

Every entry carries the **date**, the **author** (display name, user ID and avatar)
and the **message text**, plus the channel and server it came from.

---

## Read this first

- **Discord's terms of service prohibit modifying the client.** Message loggers are
  common, but using one carries some risk to your account. That is your call to make.
- **Recording what other people delete is a privacy question, not just a technical
  one.** Some servers ban it outright, and some jurisdictions regulate it. Check the
  rules where you are.
- GhostLog is deliberately built to be as low-risk as this category gets:
  it reads only what is already painted on your screen. It **never** reads your
  token and **never** hooks the gateway WebSocket. There is no server, no
  telemetry, no account, and nothing ever leaves your machine.
- **One exception, worth stating plainly:** to keep a deleted image, video or
  voice note viewable, the extension downloads that file from Discord's own CDN
  (`cdn.discordapp.com` / `media.discordapp.net`) and stores the bytes locally.
  Those links are signed and expire, so saving the URL alone is useless — the
  file has to be captured while the link still works. This is the only network
  request GhostLog makes, it goes only to Discord, and it only ever fetches media
  your own client already displayed. Set **Save images, video & audio** to
  *never* to switch it off entirely.
- **Stealth mode** (in the popup) makes it purely observational — it writes nothing
  into the page at all, not one node or attribute.

---

## Install

1. Open `chrome://extensions`.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select this `discord-ghostlog` folder.
4. Open <https://discord.com/app> and use it normally.

The archive opens from the toolbar icon, or from `chrome://extensions` → GhostLog →
**Extension options**.

> Works in any Chromium browser with Manifest V3: Chrome, Edge, Brave, Opera, Vivaldi.

---

## What it does

### The core

| | |
|---|---|
| **Deleted messages stay put** | A removed message is re-inserted where it was, tinted red with a `DELETED` tag, the author's name, when it was sent and when it disappeared. |
| **Edit history** | When someone edits a message, the old version is kept. A `✎n` badge appears on the message; hover it to read the previous versions. |
| **The archive** | Every rendered message is written to a local database — date, author, user ID, server, channel, text, attachments and replies. |
| **Attachments are kept** | Images, video and audio are downloaded and stored, so a deleted photo still shows, a deleted clip still plays, and a deleted voice note still has sound — long after Discord's link has expired. |
| **Search and filter** | Full-text search across message, author and channel, plus filters for server, channel, author, date range, deleted-only and edited-only. |
| **Export** | The whole archive as JSON, or as a CSV with `date, time, author, author_id, server, channel, message, deleted, deleted_at, edits, message_id`. |

### The extras

- **Keyword watch** — highlight messages containing your words, with an optional
  desktop notification. Useful for a name or a project that gets mentioned while
  you are away.
- **Always-on timestamps** — Discord hides the time on grouped messages until you
  hover; this pins them visible.
- **Sidebar counts** — a purple badge on a server icon, channel or DM showing how
  many messages were deleted there while you were away. Opening the channel clears
  it. Toggle with **Purple count on servers and DMs**.
- **In-chat counter** — a small pill showing how many deletions were caught in this
  channel. Click it to open the archive filtered to that channel.
- **Ghost actions** — hover a ghost to copy its text, copy the message ID, jump to
  the archive, or dismiss it.
- **Custom accent colour** and an optional auto-hide timer for ghosts.
- **Jump back to Discord** — every archive entry links to the original message.

### Privacy controls

- **Master switch** — pause all logging.
- **Stealth mode** — archive silently, touching nothing in the page.
- **Mute a server** — one click in the popup; that server is never recorded.
- **Never log DMs** — a single toggle.
- **Retention** — keep history for 1 / 7 / 30 / 90 days or forever, plus a 50,000
  record cap. Old records are pruned automatically every three hours.
- **Forget selection** — delete everything archived from one server or channel.
- **Erase all** — wipe the database.

---

## How deletion detection works

There is no event to listen to, so GhostLog watches the message list and works out
what a removal *means*. A node leaving the DOM is usually not a deletion — Discord
virtualises the list and React re-renders constantly. A removal is only treated as
a real delete when **all** of these hold:

1. The removal was not part of a sweep of more than 25 messages (that is a re-render).
2. You had not scrolled in the last 900 ms (scrolling is what triggers virtualisation).
3. You did not change channel.
4. The message list itself is still on the page.
5. After 750 ms, the message has **not** come back — which rules out a React re-mount.
6. It was not a message of your own being confirmed (see below).

### Messages you send

Discord renders a message you send **optimistically**: it appears instantly under a
temporary nonce id, and only once the server acknowledges it does the real message
id arrive — either as a replacement node or by rewriting the id on the existing one.
Naively, the temporary node disappearing looks exactly like a deletion, which is why
an unfixed logger flags everything you type as `DELETED`.

GhostLog handles all three forms of this:

- A message still in Discord's *sending* state is never a deletion candidate, and is
  not archived under its throwaway id.
- If a node is replaced, the removal is matched against messages that appeared in the
  same instant with the same author and text. A match means a confirmed send, not a
  deletion, and the temporary record is dropped from the archive.
- If the id is rewritten in place, the record is re-keyed so the message is archived
  under its real id.
- A send that never re-renders at all is archived by a fallback four seconds later,
  so nothing you type goes unrecorded.

**Strict mode** adds a sixth condition: the messages directly above and below must
both still be on screen. It nearly eliminates false positives at the cost of missing
some real deletions near the edges of the list.

### Deletions that happened while you were away

Watching the list only catches what happens in front of you. So when you open a
channel, GhostLog also compares what is on screen against what it already has
archived for that same span of time. Anything it holds that sits between two
messages still on screen, but is no longer there, was deleted while you were
gone — it gets marked and a ghost appears in place, labelled **deleted while you
were away**. Scrolling up re-runs the check as older history renders, so the
further back you scroll, the more it can recover.

The comparison is deliberately bounded by the messages actually on screen. A gap
can only be claimed *between* two surviving messages, never past the ends, which
is what stops ordinary virtualisation from looking like a mass deletion.

Because the exact moment is unknowable, these are recorded as inferred: the
archive shows "found gone" rather than a deletion time, and the detail panel says
so outright. Turn it off with **Show deletions you missed when opening a channel**.

One known false positive: if you block someone, Discord stops rendering their
messages, so anything of theirs already archived will look like a gap.

### Where a ghost goes

A ghost is placed by **time**, between the messages it sat between — never
appended to the end of the channel. If the spot it belongs in has not rendered
yet (you are scrolled away, or that part of the history has not loaded), the
ghost is **held back** rather than stranded at the bottom, and it drops into
place as soon as that stretch of the channel renders.

Ghosts also survive the list being rebuilt. Every deletion already on record for
the visible span is redrawn when a channel loads, so refreshing the page no
longer wipes them — the archive is the source of truth, not the page. A ghost you
dismiss with **×** stays dismissed until you switch channels.

### Attachments

Discord serves uploads from a signed CDN URL that expires, so an archived link is
worthless by the time you want it. GhostLog therefore keeps the **file itself**.

- **Images** render inline in the ghost and in the archive, at full size.
- **Video** gets a real player with controls, in both places.
- **Audio and voice notes** get an audio player.
- Anything else is recorded by name; only media is downloaded.

By default this happens **when a message is deleted** — the last moment the CDN
link is reliably still valid. Set it to *every message* to keep everything, or
*never* to store nothing. Per-file caps (8 MB images, 12 MB audio, 25 MB video)
and a total budget (500 MB by default, oldest evicted first) keep it bounded, and
files above the inline limit stay viewable in the archive.

Where the bytes were not captured — the link had already expired, or the file was
over a cap — the ghost says so rather than offering a link that will not load.
The archive's detail panel also offers **Save file** to pull a copy back out.

### DMs and group chats

Direct messages and group chats work the same as servers: they are archived,
ghosted and backfilled identically. Two things are specific to them:

- They have no server, so they group under **Direct Messages** in the archive,
  with the person or group name as the channel.
- Their away-deletion badge appears on the **home button** in the server rail as
  well as on the individual conversation, since that is where they live.

**Never log direct messages** excludes them from everything — archiving, the gap
scan and the badges alike.

### Performance

Two things dominate the cost, and both are deliberately bounded:

- **The gap scan** asks "this channel, between these two times". A compound
  index answers that as a range lookup rather than a walk of every message in
  the channel. It runs when you open a channel or when older history renders —
  never once per removed message, which is what made scrolling crawl.
- **Attachments** are never decoded until something will actually show them. A
  ghost off screen loads nothing; images under 3 MB appear when it scrolls into
  view; video and audio wait for a click. Encoding a 25 MB video to display it
  in a ghost nobody looked at was the other half of the slowness.

A removal blamed on scrolling gets one cheap second look five seconds later: if
the message is still missing and its time sits strictly inside what is on
screen, it was a deletion after all. That check reads the visible list only and
touches no database.

### What it cannot see

- **Messages that never rendered.** If a message was posted and deleted while you
  were in another channel, or before you scrolled back far enough, it was never on
  your screen and cannot be archived. This is a logger, not a time machine.
- **Usernames (`@handle`).** Discord does not put the handle in the message list —
  only the display name. GhostLog records the display name plus the numeric user ID,
  which is stable even when someone changes their name.
- **Attachment contents.** Attachment URLs are archived, but Discord's CDN links are
  signed and expire, so an old link may no longer resolve. The filename stays.

---

## Settings reference

| Setting | Default | Effect |
|---|---|---|
| `enabled` | on | Master switch for all logging |
| `ghostsInline` | on | Re-insert deleted messages into the chat |
| `logEdits` | on | Keep previous versions of edited messages |
| `strictMode` | off | Require surviving neighbours before ghosting |
| `stealth` | off | Archive only; write nothing into the page |
| `backfill` | on | On opening a channel, surface deletions you missed |
| `sidebarBadges` | on | Purple away-deletion count on servers, channels and DMs |
| `storeMedia` | deleted | Keep attachment bytes: `off` / `deleted` / `all` |
| `mediaMaxImageMB` | 8 | Per-image size cap |
| `mediaMaxAudioMB` | 12 | Per-audio size cap |
| `mediaMaxVideoMB` | 25 | Per-video size cap |
| `mediaBudgetMB` | 500 | Total media store; oldest evicted past this |
| `debug` | off | Narrate every decision to the page console |
| `alwaysTimestamps` | on | Show times on grouped messages |
| `accent` | `#ed4245` | Ghost tint colour |
| `ghostFade` | never | Auto-hide ghosts after n seconds |
| `keywords` | none | Words to highlight |
| `notifyKeywords` | off | Desktop notification on a keyword hit |
| `ignoredGuilds` | none | Servers never recorded |
| `ignoreDMs` | off | Never record direct messages |
| `retentionDays` | 30 | Prune records older than this |
| `maxRecords` | 50000 | Hard cap; oldest pruned first |

---

## Layout

```
manifest.json              MV3 manifest
src/
  content/logger.js        watches the chat list, detects deletions, draws ghosts
  content/ghost.css        ghost, badge and counter styling
  background/sw.js         message router and session counters
  background/db.js         IndexedDB store, queries, retention, attachment bytes
  background/defaults.js   shared settings defaults
  popup/                   toolbar popup: toggles, stats, privacy controls
  viewer/                  the archive: search, filters, export
tools/
  make-icons.js            generates the icons (no dependencies)
  validate.js              structural checks across manifest, HTML, JS and CSS
  testbed/                 a fake Discord DOM for exercising the detection logic
```

---

## Development

```bash
node tools/validate.js
```

Checks that every manifest path exists, every `getElementById` has a matching id,
every message type has a service-worker handler, the content script's inlined
settings mirror `defaults.js`, and the CSS defines every class the JS creates.

```bash
node tools/testbed/server.js
```

Serves a replica of Discord's message-list DOM at
`http://localhost:8731/channels/111222333444555666/777888999000111222`, loads the
real `logger.js` against it with a stubbed `chrome` API, and runs 47 assertions
covering capture, author inheritance, ghost placement, edits, keyword marking,
stealth, and — most importantly — that virtualisation, scrolling, React re-renders
your own outgoing messages, and recycled list nodes are **not** mistaken for
deletions — plus the away-deletion backfill. Results render in the right-hand panel.

`http://localhost:8731/viewer-demo` renders the real archive page against
fabricated records, so the viewer can be checked without installing anything.

Append `?focus=1` to that URL for a second, much shorter suite (22 assertions)
covering ghost placement, held-back ghosts, redraw after a rebuild, the sidebar
badges, attachment classification, media playback inside a ghost, and DM /
group-chat badging. It runs in isolation rather than after fifty other scenarios,
so it is the faster loop when working on those.

```bash
node tools/make-icons.js
```

Regenerates the PNG icons from code.

---

## If it stops catching deletions

Discord ships UI changes regularly. GhostLog deliberately keys off stable hooks —
`ol[data-list-id="chat-messages"]`, `id="chat-messages-…"`, `id="message-content-…"`
— rather than the hashed class names, so it should survive most redesigns. If a
change does break it, `tools/testbed` is the place to reproduce it: update the
fixture DOM in `harness.html` to match the new markup and the assertions will tell
you exactly which part broke.

If you get **false** ghosts (messages marked deleted that were not), turn on
**strict mode**.

If deletions are **not** being caught, turn on **Debug** in the popup and open the
page console on Discord (F12). Every removal is then reported with the exact rule
that rejected it — "you had just scrolled (virtualisation)", "the message came
straight back (re-render)", and so on — which says immediately whether the message
is not being seen at all or is being seen and dismissed. If your *own* messages are being flagged the moment you send them,
Discord has changed how it marks a pending send — scenario J in the testbed covers
exactly that case and will pinpoint it.
