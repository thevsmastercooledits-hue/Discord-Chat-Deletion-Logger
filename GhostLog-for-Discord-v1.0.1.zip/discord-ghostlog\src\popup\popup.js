const $ = (id) => document.getElementById(id);

function send(type, payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, payload }, (res) => {
      void chrome.runtime.lastError;
      resolve(res && res.ok ? res.result : null);
    });
  });
}

function humanBytes(n) {
  if (!n) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n < 10 ? n.toFixed(1) : Math.round(n)} ${units[i]}`;
}

function note(text, good) {
  const el = $('note');
  el.textContent = text;
  el.classList.toggle('flash', !!good);
  clearTimeout(note._t);
  note._t = setTimeout(() => {
    el.textContent = 'Local only. Nothing leaves this machine.';
    el.classList.remove('flash');
  }, 2600);
}

let settings = null;
let currentGuild = null;

const CHECKBOXES = ['enabled', 'ghostsInline', 'logEdits', 'alwaysTimestamps', 'strictMode', 'stealth', 'backfill', 'sidebarBadges', 'debug', 'notifyKeywords', 'ignoreDMs'];

async function patch(partial) {
  settings = await send('settings:set', partial);
  paint();
}

function paint() {
  for (const key of CHECKBOXES) $(key).checked = !!settings[key];
  $('accent').value = settings.accent;
  $('ghostFade').value = String(settings.ghostFade);
  $('retentionDays').value = String(settings.retentionDays);
  $('keywords').value = (settings.keywords || []).join(', ');
  $('storeMedia').value = settings.storeMedia || 'deleted';
  $('mediaBudgetMB').value = String(settings.mediaBudgetMB || 500);
  $('statusDot').classList.toggle('on', !!settings.enabled);

  const list = $('ignoredList');
  list.textContent = '';
  if (settings.ignoredGuilds.length === 0) {
    list.textContent = 'No servers muted.';
  } else {
    for (const id of settings.ignoredGuilds) {
      const chip = document.createElement('span');
      chip.textContent = id;
      chip.title = 'Click to resume logging this server';
      chip.addEventListener('click', () => {
        patch({ ignoredGuilds: settings.ignoredGuilds.filter((g) => g !== id) });
      });
      list.appendChild(chip);
    }
  }

  const btn = $('ignoreGuild');
  if (!currentGuild) {
    btn.textContent = 'Open a server to mute it';
    btn.disabled = true;
    btn.style.opacity = 0.5;
  } else if (settings.ignoredGuilds.includes(currentGuild)) {
    btn.textContent = 'Resume logging this server';
    btn.disabled = false;
    btn.style.opacity = 1;
  } else {
    btn.textContent = 'Stop logging the current server';
    btn.disabled = false;
    btn.style.opacity = 1;
  }
}

async function refreshMediaUsage() {
  const u = await send('media:usage');
  if (!u) return;
  $('mediaUsage').textContent = u.count
    ? `${u.count.toLocaleString()} files · ${humanBytes(u.bytes)} of ${humanBytes(u.budgetBytes)}`
    : 'Nothing stored yet.';
}

async function refreshStats() {
  const stats = await send('stats');
  if (!stats) return;
  $('statTotal').textContent = stats.total.toLocaleString();
  $('statDeleted').textContent = stats.deleted.toLocaleString();
  $('statSize').textContent = humanBytes(stats.bytes);
}

async function detectGuild() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) return;
  const m = /discord\.com\/channels\/(\d+)\//.exec(tab.url);
  currentGuild = m ? m[1] : null;
}

async function init() {
  settings = await send('settings:get');
  await detectGuild();
  paint();
  refreshStats();
  refreshMediaUsage();

  for (const key of CHECKBOXES) {
    $(key).addEventListener('change', (e) => patch({ [key]: e.target.checked }));
  }
  $('accent').addEventListener('input', (e) => patch({ accent: e.target.value }));
  $('storeMedia').addEventListener('change', (e) => patch({ storeMedia: e.target.value }));
  $('mediaBudgetMB').addEventListener('change', (e) => patch({ mediaBudgetMB: Number(e.target.value) }));

  $('clearMedia').addEventListener('click', async () => {
    const btn = $('clearMedia');
    if (btn.dataset.armed !== '1') {
      btn.dataset.armed = '1';
      btn.textContent = 'Really delete the files?';
      setTimeout(() => { btn.dataset.armed = '0'; btn.textContent = 'Delete stored files'; }, 4000);
      return;
    }
    await send('media:clear');
    btn.dataset.armed = '0';
    btn.textContent = 'Delete stored files';
    note('Stored files deleted', true);
    refreshMediaUsage();
  });
  $('ghostFade').addEventListener('change', (e) => patch({ ghostFade: Number(e.target.value) }));
  $('retentionDays').addEventListener('change', async (e) => {
    const days = Number(e.target.value);
    await patch({ retentionDays: days });
    // apply the new window immediately rather than waiting for the next sweep
    if (days > 0) {
      const res = await send('purge:older', { days });
      if (res && res.removed) note(`Pruned ${res.removed.toLocaleString()} old records`, true);
      refreshStats();
    }
  });

  let kwTimer;
  $('keywords').addEventListener('input', (e) => {
    clearTimeout(kwTimer);
    kwTimer = setTimeout(() => {
      const words = e.target.value.split(',').map((s) => s.trim()).filter(Boolean);
      patch({ keywords: words });
      note('Keywords saved', true);
    }, 500);
  });

  $('ignoreGuild').addEventListener('click', () => {
    if (!currentGuild) return;
    const muted = settings.ignoredGuilds.includes(currentGuild);
    patch({
      ignoredGuilds: muted
        ? settings.ignoredGuilds.filter((g) => g !== currentGuild)
        : [...settings.ignoredGuilds, currentGuild]
    });
    note(muted ? 'Logging resumed' : 'Server muted', !muted);
  });

  $('openViewer').addEventListener('click', () => {
    send('open:viewer', {});
    window.close();
  });

  $('clearAll').addEventListener('click', async () => {
    const btn = $('clearAll');
    if (btn.dataset.armed !== '1') {
      btn.dataset.armed = '1';
      btn.textContent = 'Really erase?';
      note('Click again to erase everything.');
      setTimeout(() => { btn.dataset.armed = '0'; btn.textContent = 'Erase all'; }, 4000);
      return;
    }
    await send('purge:all');
    btn.dataset.armed = '0';
    btn.textContent = 'Erase all';
    note('Archive erased', true);
    refreshStats();
    refreshMediaUsage();
  });
}

init();
