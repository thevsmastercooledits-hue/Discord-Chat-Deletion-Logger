import {
  upsertMessage, markDeleted, appendEdit, queryMessages, countAll, countDeleted,
  facets, findGaps, findDeletedInRange, awayCounts,
  mediaKey, putMedia, getMedia, hasMedia, mediaForMessage, mediaUsage, pruneMedia, clearMedia,
  deleteWhere, deleteById, clearAll, exportAll, prune, openDB
} from './db.js';
import { DEFAULTS, getSettings, setSettings } from './defaults.js';

// ---------------------------------------------------------------------------
// lifetime
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener(async (details) => {
  const stored = await chrome.storage.local.get('settings');
  if (!stored.settings) await chrome.storage.local.set({ settings: DEFAULTS });
  await openDB();
  chrome.alarms.create('ghostlog-prune', { periodInMinutes: 180 });
  if (details.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/viewer/viewer.html#welcome') });
  }
});

chrome.runtime.onStartup?.addListener(() => {
  chrome.alarms.create('ghostlog-prune', { periodInMinutes: 180 });
});

chrome.alarms?.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'ghostlog-prune') return;
  const s = await getSettings();
  await prune({ retentionDays: s.retentionDays, maxRecords: s.maxRecords });
});

// ---------------------------------------------------------------------------
// session counters (cheap, in-memory; the badge reads these)
// ---------------------------------------------------------------------------

const session = { logged: 0, deleted: 0, edited: 0 };

// counting away-deletions walks the store, so hold the result until it changes
let badgeCache = null;

// running total of stored media, so the budget check is not a full scan per file
let mediaBytes = null;

// ---------------------------------------------------------------------------
// attachment capture
// ---------------------------------------------------------------------------

const MEDIA_HOSTS = /^https:\/\/(cdn\.discordapp\.com|media\.discordapp\.net)\//;

function sizeCapFor(kind, s) {
  if (kind === 'image') return (s.mediaMaxImageMB || 8) * 1048576;
  if (kind === 'audio') return (s.mediaMaxAudioMB || 12) * 1048576;
  if (kind === 'video') return (s.mediaMaxVideoMB || 25) * 1048576;
  return 0; // other files are recorded but not downloaded
}

/**
 * Fetch one attachment and keep the bytes. Discord's CDN links are signed and
 * expire, so the URL alone is worthless once a message is gone — the file has
 * to be captured while the link still works.
 */
async function captureOne(att, message, s) {
  if (!att || !MEDIA_HOSTS.test(att.url)) return { skipped: 'not a Discord CDN url' };

  const cap = sizeCapFor(att.kind, s);
  if (!cap) return { skipped: 'kind not stored' };

  const id = mediaKey(att.url);
  if (await hasMedia(id)) return { skipped: 'already stored' };

  let res;
  try {
    res = await fetch(att.url, { credentials: 'omit', cache: 'force-cache' });
  } catch (err) {
    return { error: String(err && err.message || err) };
  }
  if (!res.ok) return { error: 'HTTP ' + res.status };

  const declared = Number(res.headers.get('content-length') || 0);
  if (declared && declared > cap) return { skipped: 'over the size cap' };

  const blob = await res.blob();
  if (blob.size > cap) return { skipped: 'over the size cap' };

  await putMedia({
    id,
    messageId: message.id,
    channelId: message.channelId || null,
    guildId: message.guildId || null,
    kind: att.kind,
    name: att.name || null,
    type: blob.type || res.headers.get('content-type') || '',
    size: blob.size,
    blob,
    savedAt: Date.now()
  });

  const budget = (s.mediaBudgetMB || 500) * 1048576;
  if (mediaBytes === null) mediaBytes = (await mediaUsage()).bytes;
  else mediaBytes += blob.size;
  if (mediaBytes > budget) {
    await pruneMedia(budget);
    mediaBytes = (await mediaUsage()).bytes;
  }
  return { stored: true, size: blob.size };
}

/**
 * Runtime messaging is JSON-only, so blobs have to cross as data URLs.
 * Built from an ArrayBuffer rather than FileReader, which is not dependably
 * present in a service worker.
 */
async function blobToDataUrl(blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let binary = '';
  const CHUNK = 0x8000; // chunked, or a large file blows the argument limit
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return `data:${blob.type || 'application/octet-stream'};base64,${btoa(binary)}`;
}

async function captureAll(message, s) {
  const list = (message.attachments || []).filter((a) => a.kind !== 'file');
  const results = [];
  for (const att of list.slice(0, 8)) results.push(await captureOne(att, message, s));
  return results;
}

function bumpBadge() {
  const n = session.deleted;
  chrome.action.setBadgeText({ text: n > 0 ? (n > 999 ? '999+' : String(n)) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#ed4245' });
}

// ---------------------------------------------------------------------------
// message router
// ---------------------------------------------------------------------------

const handlers = {
  async 'log:batch'(payload) {
    const s = await getSettings();
    if (!s.enabled) return { skipped: true };
    let created = 0;
    for (const rec of payload.records) {
      if (rec.guildId && s.ignoredGuilds.includes(rec.guildId)) continue;
      if (!rec.guildId && s.ignoreDMs) continue;
      const res = await upsertMessage(rec);
      if (res.created) created++;
      if (res.created && s.storeMedia === 'all') captureAll(rec, s).catch(() => {});
    }
    session.logged += created;
    return { created };
  },

  // a message that turned out to be a temporary send id, not a real message
  async 'log:discard'(payload) {
    await deleteById(payload.id);
    return { ok: true };
  },

  async 'log:deleted'(payload) {
    const s = await getSettings();
    if (!s.enabled) return { skipped: true };

    // The archive write is batched on a timer, so a message deleted moments
    // after it arrived may not be stored yet. The content script ships the
    // record along with the deletion so it can always be recorded.
    if (payload.record) {
      const rec = payload.record;
      const muted = (rec.guildId && s.ignoredGuilds.includes(rec.guildId))
        || (!rec.guildId && s.ignoreDMs);
      if (muted) return { skipped: true };
      const clean = { ...rec };
      delete clean.deletedAt;
      await upsertMessage(clean);
    }

    const changed = await markDeleted(payload.id, payload.deletedAt, payload.inferred);
    if (changed) { session.deleted++; bumpBadge(); }
    if (changed && payload.inferred) badgeCache = null;

    // Grab the files now: the CDN link is signed and will stop working, and
    // this is the last moment it is reliably still valid.
    if (changed && s.storeMedia !== 'off' && payload.record) {
      captureAll(payload.record, s).catch(() => {});
    }
    return { changed };
  },

  /**
   * What the archive holds for a message — names and sizes only. Encoding the
   * bytes is deliberately a separate call: turning a 25 MB video into base64
   * and pushing it through runtime messaging is slow, and doing it for every
   * ghost the moment it rendered is what made deletions crawl.
   */
  async 'media:for'(payload) {
    const rows = await mediaForMessage(payload.messageId);
    return {
      media: rows.map((row) => ({
        id: row.id, kind: row.kind, name: row.name, type: row.type, size: row.size
      }))
    };
  },

  /** The bytes for one attachment, fetched only when something will show it. */
  async 'media:one'(payload) {
    const row = await getMedia(payload.id);
    if (!row) return { missing: true };
    return {
      id: row.id, kind: row.kind, name: row.name, type: row.type,
      size: row.size, dataUrl: await blobToDataUrl(row.blob)
    };
  },

  async 'media:usage'() {
    const s = await getSettings();
    const usage = await mediaUsage();
    return { ...usage, budgetBytes: (s.mediaBudgetMB || 500) * 1048576 };
  },

  async 'media:clear'() {
    await clearMedia();
    mediaBytes = 0;
    return { ok: true };
  },

  // messages the archive holds for this channel that are no longer on screen
  async 'backfill:scan'(payload) {
    const s = await getSettings();
    if (!s.enabled || !s.backfill) return { rows: [], known: [] };
    if (payload.guildId && s.ignoredGuilds.includes(payload.guildId)) return { rows: [], known: [] };
    if (!payload.guildId && s.ignoreDMs) return { rows: [], known: [] };
    const [rows, known] = await Promise.all([
      findGaps(payload.channelId, payload.minTs, payload.maxTs, payload.presentIds || []),
      findDeletedInRange(payload.channelId, payload.minTs, payload.maxTs)
    ]);
    // "known" lets a ghost survive a page refresh instead of disappearing
    return { rows, known };
  },

  async 'badge:counts'() {
    const s = await getSettings();
    if (!s.enabled || !s.sidebarBadges) return { byChannel: {}, byGuild: {} };
    if (badgeCache) return badgeCache;
    const stored = await chrome.storage.local.get('acks');
    badgeCache = await awayCounts(stored.acks || {});
    return badgeCache;
  },

  // opening a channel clears its badge
  async 'badge:ack'(payload) {
    const stored = await chrome.storage.local.get('acks');
    const acks = stored.acks || {};
    acks[payload.channelId] = Date.now();
    await chrome.storage.local.set({ acks });
    badgeCache = null;
    return { ok: true };
  },

  async 'log:edited'(payload) {
    const s = await getSettings();
    if (!s.enabled || !s.logEdits) return { skipped: true };
    const changed = await appendEdit(payload.id, payload.previousContent, payload.at);
    if (changed) session.edited++;
    return { changed };
  },

  async 'notify:keyword'(payload) {
    const s = await getSettings();
    if (!s.notifyKeywords) return { skipped: true };
    chrome.notifications.create({
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon128.png'),
      title: `${payload.authorName} in #${payload.channelName}`,
      message: payload.content.slice(0, 180),
      priority: 1
    });
    return { ok: true };
  },

  async 'query'(payload) { return queryMessages(payload || {}); },

  async 'stats'() {
    const [total, deleted] = await Promise.all([countAll(), countDeleted()]);
    let bytes = 0;
    try { bytes = (await navigator.storage.estimate()).usage || 0; } catch { /* not critical */ }
    return { total, deleted, bytes, session };
  },

  async 'facets'() { return facets(); },

  async 'settings:get'() { return getSettings(); },

  async 'settings:set'(payload) {
    const next = await setSettings(payload);
    // push straight to every open Discord tab so changes apply without a reload
    const tabs = await chrome.tabs.query({ url: '*://*.discord.com/*' });
    for (const t of tabs) {
      chrome.tabs.sendMessage(t.id, { type: 'settings:changed', payload: next }).catch(() => {});
    }
    return next;
  },

  async 'export'(payload) {
    const rows = await exportAll();
    return { rows, format: payload?.format || 'json' };
  },

  async 'purge:guild'(payload) {
    const n = await deleteWhere((r) => r.guildId === payload.guildId);
    return { removed: n };
  },

  async 'purge:channel'(payload) {
    const n = await deleteWhere((r) => r.channelId === payload.channelId);
    return { removed: n };
  },

  async 'purge:older'(payload) {
    const cutoff = Date.now() - payload.days * 86400000;
    const n = await deleteWhere((r) => r.ts < cutoff);
    return { removed: n };
  },

  async 'purge:all'() {
    await clearAll();
    await clearMedia();
    mediaBytes = 0;
    badgeCache = null;
    session.logged = 0; session.deleted = 0; session.edited = 0;
    bumpBadge();
    return { ok: true };
  },

  async 'open:viewer'(payload) {
    const hash = payload?.hash ? `#${payload.hash}` : '';
    chrome.tabs.create({ url: chrome.runtime.getURL('src/viewer/viewer.html') + hash });
    return { ok: true };
  }
};

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const handler = handlers[msg?.type];
  if (!handler) { sendResponse({ error: `unknown message type: ${msg?.type}` }); return false; }
  handler(msg.payload)
    .then((result) => sendResponse({ ok: true, result }))
    .catch((err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
  return true; // keep the channel open for the async reply
});
